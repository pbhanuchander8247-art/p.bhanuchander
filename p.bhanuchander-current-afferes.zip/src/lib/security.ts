export function safeExternalHref(url: unknown): string | null {
  if (typeof url !== 'string') return null;
  const trimmed = url.trim();
  if (!trimmed) return null;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

export function sanitizeInputText(value: string, maxLen: number): string {
  return value.replace(/[\u0000-\u001F\u007F]/g, '').slice(0, maxLen);
}
