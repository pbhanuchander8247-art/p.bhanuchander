const SESSION_TOKEN_KEY = 'pb_ca_session_token';
const DEVICE_TOKEN_MAP_KEY = 'pb_ca_device_tokens';

let onUnauthorizedCallback: (() => void) | null = null;

export function registerUnauthorizedHandler(cb: () => void): void {
  onUnauthorizedCallback = cb;
}

export function getStoredSessionToken(): string {
  try {
    const raw = localStorage.getItem(SESSION_TOKEN_KEY) || '';
    // Basic JWT/HMAC token structural check
    if (raw && /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(raw)) {
      return raw;
    }
    return '';
  } catch {
    return '';
  }
}

export function setStoredSessionToken(token: string): void {
  try {
    if (token && /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(token)) {
      localStorage.setItem(SESSION_TOKEN_KEY, token);
    } else {
      localStorage.removeItem(SESSION_TOKEN_KEY);
    }
  } catch {
    // Ignore storage errors in restricted contexts
  }
}

export function getDeviceTokenForEmail(email: string): string {
  try {
    const raw = localStorage.getItem(DEVICE_TOKEN_MAP_KEY);
    if (!raw) return '';
    const map = JSON.parse(raw) as Record<string, string>;
    const token = map[email.trim().toLowerCase()] || '';
    return /^[a-f0-9]{64}$/.test(token) ? token : '';
  } catch {
    return '';
  }
}

export function setDeviceTokenForEmail(email: string, token: string): void {
  try {
    const normalized = email.trim().toLowerCase();
    const raw = localStorage.getItem(DEVICE_TOKEN_MAP_KEY);
    const map = raw ? (JSON.parse(raw) as Record<string, string>) : {};
    if (token && /^[a-f0-9]{64}$/.test(token)) {
      map[normalized] = token;
    } else {
      delete map[normalized];
    }
    localStorage.setItem(DEVICE_TOKEN_MAP_KEY, JSON.stringify(map));
  } catch {
    // Ignore storage errors
  }
}

export async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  if (!path.startsWith('/api/')) {
    throw new Error('Blocked unsafe API request path.');
  }

  const token = getStoredSessionToken();
  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const res = await fetch(path, {
    ...options,
    headers,
    credentials: 'same-origin',
  });

  if (res.status === 401 && path !== '/api/auth/verify-otp' && path !== '/api/auth/login') {
    setStoredSessionToken('');
    onUnauthorizedCallback?.();
  }

  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}
