export type Language = 'en' | 'te';

export type EducationLevel =
  | 'High School / 10+2'
  | 'Undergraduate / Degree'
  | 'Postgraduate'
  | 'UPSC Civil Services'
  | 'APPSC / TSPSC Group 1 & 2'
  | 'SSC / RRB / Banking';

export type NewsCategory =
  | 'all'
  | 'regional'
  | 'national'
  | 'international'
  | 'economy'
  | 'science'
  | 'sports';

export interface BilingualText {
  en: string;
  te: string;
}

export interface GroundedSource {
  title: string;
  url: string;
}

export interface NewsArticle {
  id: string;
  category: Exclude<NewsCategory, 'all'>;
  isBreaking?: boolean;
  isLead?: boolean;
  publishedAt: string;
  readMinutes: number;
  imageUrl?: string;
  title: BilingualText;
  summary: BilingualText;
  body: BilingualText;
  examRelevance: BilingualText;
  examTags: string[];
  sources: GroundedSource[];
}

export interface QuizQuestion {
  id: string;
  category: Exclude<NewsCategory, 'all'>;
  examTrack: string;
  question: BilingualText;
  options: BilingualText[];
  correctIndex: number;
  explanation: BilingualText;
}

export interface MockTestDeck {
  id: string;
  title: BilingualText;
  examTrack: string;
  durationMinutes: number;
  positiveMarks: number;
  negativeMarks: number;
  questions: QuizQuestion[];
}

export interface GlossaryTerm {
  id: string;
  category: 'Polity' | 'Economy' | 'Science' | 'Environment' | 'International';
  term: BilingualText;
  definition: BilingualText;
  examContext: BilingualText;
}

export interface QuizAttempt {
  id: string;
  deckId: string;
  deckTitle: string;
  examTrack: string;
  score: number;
  maxScore: number;
  accuracyPercent: number;
  correctCount: number;
  totalQuestions: number;
  completedAt: string;
}

export interface StudentProfile {
  name: string;
  email: string;
  educationLevel: EducationLevel;
  otpVerified: boolean;
  verifiedAt: string;
  quizAttempts: QuizAttempt[];
  bookmarkedIds: string[];
  searchHistory?: string[];
}

export interface InfographicMetric {
  label: BilingualText;
  value: number;
  unit: string;
  previousValue: number;
  detail: BilingualText;
}

export interface TimelineMilestone {
  year: string;
  title: BilingualText;
  description: BilingualText;
  sector: BilingualText;
}

export interface ConstitutionalHighlight {
  article: string;
  title: BilingualText;
  significance: BilingualText;
  recentNewsLink: BilingualText;
}
