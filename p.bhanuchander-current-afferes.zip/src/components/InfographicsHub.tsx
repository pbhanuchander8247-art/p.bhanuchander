import React, { useState } from 'react';
import { BarChart3, BookOpenCheck, Compass, Scale } from 'lucide-react';
import {
  CONSTITUTION_HIGHLIGHTS,
  MACRO_METRICS,
  TECH_TIMELINE,
} from '../data/bilingualContent';
import type { Language, QuizAttempt } from '../types';

interface InfographicsHubProps {
  lang: Language;
  attempts: QuizAttempt[];
  savedCount: number;
}

export const InfographicsHub: React.FC<InfographicsHubProps> = ({
  lang,
  attempts,
  savedCount,
}) => {
  const [showComparison, setShowComparison] = useState(true);
  const [activeYearIdx, setActiveYearIdx] = useState(TECH_TIMELINE.length - 1);
  const [selectedArticleIdx, setSelectedArticleIdx] = useState(0);

  const isTe = lang === 'te';
  const activeMilestone = TECH_TIMELINE[activeYearIdx];
  const activeConstitution = CONSTITUTION_HIGHLIGHTS[selectedArticleIdx];

  const avgAccuracy =
    attempts.length > 0
      ? Math.round(
          attempts.reduce((sum, a) => sum + a.accuracyPercent, 0) / attempts.length
        )
      : 0;

  return (
    <div className="space-y-8">
      {/* Personal Exam Readiness Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-5">
          <div className="text-xs text-stone-500 dark:text-slate-400">
            {isTe ? 'పూర్తి చేసిన మాక్ టెస్టులు' : 'Mock Tests Completed'}
          </div>
          <div className="font-mono-tabular text-2xl font-semibold text-stone-900 dark:text-white mt-1">
            {attempts.length}
          </div>
        </div>
        <div className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-5">
          <div className="text-xs text-stone-500 dark:text-slate-400">
            {isTe ? 'సగటు ఖచ్చితత్వం' : 'Average Accuracy'}
          </div>
          <div className="font-mono-tabular text-2xl font-semibold text-[#1E3A8A] dark:text-[#38BDF8] mt-1">
            {avgAccuracy}%
          </div>
        </div>
        <div className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-5">
          <div className="text-xs text-stone-500 dark:text-slate-400">
            {isTe ? 'సేవ్ చేసిన వార్తలు' : 'Saved Revision Briefings'}
          </div>
          <div className="font-mono-tabular text-2xl font-semibold text-stone-900 dark:text-white mt-1">
            {savedCount}
          </div>
        </div>
      </section>

      {/* Infographic 1: Interactive Macro & Policy Indicators */}
      <section className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <BarChart3 className="w-5 h-5 text-[#1E3A8A] dark:text-[#38BDF8] mt-1 shrink-0" />
            <div>
              <h2 className="font-display text-xl sm:text-2xl font-semibold text-stone-900 dark:text-white">
                {isTe
                  ? 'భారత ఆర్థిక & డిజిటల్ మౌలిక సదుపాయాల సూచికలు'
                  : 'India Macro, Clean Energy & Digital Public Infrastructure Snapshot'}
              </h2>
              <p className="text-sm text-stone-600 dark:text-slate-400 mt-1">
                {isTe
                  ? 'గత బేస్‌లైన్ పోలికతో కీలక పరీక్షా గణాంకాలను పరిశీలించండి.'
                  : 'Compare current policy benchmarks against prior baseline levels for UPSC/Group-1 Economy.'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowComparison((v) => !v)}
            className="px-3.5 py-2 rounded-lg border border-stone-300 dark:border-slate-700 text-xs font-medium text-stone-800 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {showComparison
              ? isTe
                ? 'గత బేస్‌లైన్ దాచండి'
                : 'Hide Baseline Comparison'
              : isTe
                ? 'గత బేస్‌లైన్ చూపండి'
                : 'Show Baseline Comparison'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {MACRO_METRICS.map((metric, idx) => {
            const maxVal = Math.max(metric.value, metric.previousValue) * 1.15;
            const curPct = Math.min(100, Math.round((metric.value / maxVal) * 100));
            const prevPct = Math.min(100, Math.round((metric.previousValue / maxVal) * 100));
            const delta = Math.round((metric.value - metric.previousValue) * 10) / 10;

            return (
              <div
                key={idx}
                className="p-5 rounded-xl border border-stone-200 dark:border-slate-800 bg-[#FBF9F5] dark:bg-[#0B1120] space-y-3"
              >
                <div className="flex items-baseline justify-between gap-4">
                  <h3 className="text-sm font-semibold text-stone-900 dark:text-white">
                    {metric.label[lang]}
                  </h3>
                  <span className="font-mono-tabular text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                    +{delta} {metric.unit}
                  </span>
                </div>

                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-xs text-stone-600 dark:text-slate-400 mb-1">
                      <span>{isTe ? 'ప్రస్తుత విలువ' : 'Current'}</span>
                      <span className="font-mono-tabular font-semibold text-stone-900 dark:text-white">
                        {metric.value} {metric.unit}
                      </span>
                    </div>
                    <div className="h-2.5 w-full rounded-full bg-stone-200 dark:bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#1E3A8A] dark:bg-[#38BDF8] transition-all duration-300"
                        style={{ width: `${curPct}%` }}
                      />
                    </div>
                  </div>

                  {showComparison && (
                    <div>
                      <div className="flex justify-between text-xs text-stone-500 dark:text-slate-400 mb-1">
                        <span>{isTe ? 'గత బేస్‌లైన్' : 'Prior Baseline'}</span>
                        <span className="font-mono-tabular">
                          {metric.previousValue} {metric.unit}
                        </span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-stone-200 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-stone-400 dark:bg-slate-600 transition-all duration-300"
                          style={{ width: `${prevPct}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>

                <p className="text-xs text-stone-600 dark:text-slate-400 leading-relaxed">
                  {metric.detail[lang]}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Infographic 2: Interactive Science & Space Timeline */}
      <section className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="flex items-start gap-3">
          <Compass className="w-5 h-5 text-[#1E3A8A] dark:text-[#38BDF8] mt-1 shrink-0" />
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-semibold text-stone-900 dark:text-white">
              {isTe
                ? 'భారత సైన్స్, అంతరిక్ష & క్వాంటమ్ మైలురాళ్ళ కాలక్రమం'
                : 'Interactive Science, Space & Deep-Tech Milestones (2023–2026)'}
            </h2>
            <p className="text-sm text-stone-600 dark:text-slate-400 mt-1">
              {isTe
                ? 'సంబంధిత మిషన్ వివరాలను చూడటానికి సంవత్సరాన్ని ఎంచుకోండి.'
                : 'Select a year node to inspect mission milestones relevant to Prelims & Mains GS-III.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2 sm:gap-4">
          {TECH_TIMELINE.map((item, idx) => {
            const active = idx === activeYearIdx;
            return (
              <button
                key={item.year}
                type="button"
                onClick={() => setActiveYearIdx(idx)}
                className={`py-3 px-2 rounded-xl border text-center transition-colors cursor-pointer ${
                  active
                    ? 'border-[#1E3A8A] dark:border-[#38BDF8] bg-[#1E3A8A] dark:bg-[#2563EB] text-white'
                    : 'border-stone-200 dark:border-slate-800 bg-[#FBF9F5] dark:bg-[#0B1120] text-stone-800 dark:text-slate-300 hover:border-stone-400'
                }`}
              >
                <div className="font-mono-tabular text-lg font-semibold">{item.year}</div>
                <div className="text-[11px] opacity-85 truncate mt-0.5">{item.sector[lang]}</div>
              </button>
            );
          })}
        </div>

        <div className="p-6 rounded-xl border border-stone-200 dark:border-slate-800 bg-[#FBF9F5] dark:bg-[#0B1120] space-y-2">
          <div className="text-xs font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
            {activeMilestone.year} · {activeMilestone.sector[lang]}
          </div>
          <h3 className="font-display text-xl font-semibold text-stone-900 dark:text-white">
            {activeMilestone.title[lang]}
          </h3>
          <p className="text-sm text-stone-700 dark:text-slate-300 leading-relaxed max-w-3xl">
            {activeMilestone.description[lang]}
          </p>
        </div>
      </section>

      {/* Infographic 3: Constitutional Articles & Governance Explorer */}
      <section className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="flex items-start gap-3">
          <Scale className="w-5 h-5 text-[#1E3A8A] dark:text-[#38BDF8] mt-1 shrink-0" />
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-semibold text-stone-900 dark:text-white">
              {isTe
                ? 'వార్తల్లోని ప్రధాన రాజ్యాంగ ఆర్టికల్స్'
                : 'Constitutional Articles in Current Affairs Matrix'}
            </h2>
            <p className="text-sm text-stone-600 dark:text-slate-400 mt-1">
              {isTe
                ? 'ప్రస్తుత వార్తలతో అనుసంధానమైన కీలక ఆర్టికల్స్‌ను పరిశీలించండి.'
                : 'Connect live policy developments directly to foundational Indian Polity provisions.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 space-y-2">
            {CONSTITUTION_HIGHLIGHTS.map((item, idx) => {
              const active = idx === selectedArticleIdx;
              return (
                <button
                  key={item.article}
                  type="button"
                  onClick={() => setSelectedArticleIdx(idx)}
                  className={`w-full text-left p-4 rounded-xl border transition-colors cursor-pointer ${
                    active
                      ? 'border-[#1E3A8A] dark:border-[#38BDF8] bg-[#1E3A8A]/5 dark:bg-[#38BDF8]/10'
                      : 'border-stone-200 dark:border-slate-800 bg-[#FBF9F5] dark:bg-[#0B1120] hover:border-stone-400'
                  }`}
                >
                  <div className="font-mono-tabular text-xs font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
                    {item.article}
                  </div>
                  <div className="font-medium text-sm text-stone-900 dark:text-white mt-0.5">
                    {item.title[lang]}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="lg:col-span-7 p-6 rounded-xl border border-stone-200 dark:border-slate-800 bg-[#FBF9F5] dark:bg-[#0B1120] space-y-4">
            <div className="flex items-center gap-2 text-xs font-mono-tabular font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
              <BookOpenCheck className="w-4 h-4" />
              <span>{activeConstitution.article}</span>
            </div>
            <h3 className="font-display text-2xl font-semibold text-stone-900 dark:text-white">
              {activeConstitution.title[lang]}
            </h3>
            <div className="space-y-3 text-sm text-stone-700 dark:text-slate-300 leading-relaxed">
              <div>
                <span className="font-semibold text-stone-900 dark:text-white block mb-1">
                  {isTe ? 'రాజ్యాంగ ప్రాముఖ్యత' : 'Constitutional Mandate'}
                </span>
                {activeConstitution.significance[lang]}
              </div>
              <div className="pt-3 border-t border-stone-200 dark:border-slate-800">
                <span className="font-semibold text-stone-900 dark:text-white block mb-1">
                  {isTe ? 'ప్రస్తుత వార్తలతో అనుసంధానం' : 'Current Affairs Linkage'}
                </span>
                {activeConstitution.recentNewsLink[lang]}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
