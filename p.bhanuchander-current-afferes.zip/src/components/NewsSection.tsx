import React, { useEffect, useState } from 'react';
import {
  Bookmark,
  BookmarkCheck,
  Bot,
  ExternalLink,
  Pause,
  Play,
  RefreshCw,
  X,
} from 'lucide-react';
import { CATEGORY_LABELS } from '../data/bilingualContent';
import { safeExternalHref } from '../lib/security';
import type { Language, NewsArticle, NewsCategory } from '../types';

interface NewsSectionProps {
  lang: Language;
  articles: NewsArticle[];
  activeCategory: NewsCategory | 'saved';
  onSelectCategory: (cat: NewsCategory | 'saved') => void;
  searchQuery: string;
  bookmarkedIds: string[];
  onToggleBookmark: (articleId: string) => void;
  onAskTutorAboutArticle: (article: NewsArticle) => void;
  onRefreshLive: () => void;
  refreshing: boolean;
  lastSyncedAt: string;
  refreshError: string;
}

export const NewsSection: React.FC<NewsSectionProps> = ({
  lang,
  articles,
  activeCategory,
  onSelectCategory,
  searchQuery,
  bookmarkedIds,
  onToggleBookmark,
  onAskTutorAboutArticle,
  onRefreshLive,
  refreshing,
  lastSyncedAt,
  refreshError,
}) => {
  const [tickerPaused, setTickerPaused] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [readerMode, setReaderMode] = useState<'active' | 'both'>('active');
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (!selectedArticle) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedArticle(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectedArticle]);

  const isTe = lang === 'te';

  const breakingArticles = articles.filter((a) => a.isBreaking);
  const tickerItems = breakingArticles.length > 0 ? breakingArticles : articles.slice(0, 4);

  const normalizedQuery = searchQuery.trim().toLowerCase();
  const filteredArticles = articles.filter((article) => {
    if (activeCategory === 'saved') {
      if (!bookmarkedIds.includes(article.id)) return false;
    } else if (activeCategory !== 'all' && article.category !== activeCategory) {
      return false;
    }

    if (!normalizedQuery) return true;
    const haystack = [
      article.title.en,
      article.title.te,
      article.summary.en,
      article.summary.te,
      article.examRelevance.en,
      article.examRelevance.te,
      ...article.examTags,
    ]
      .join(' ')
      .toLowerCase();
    return haystack.includes(normalizedQuery);
  });

  const leadArticle = filteredArticles[0];
  const secondaryArticles = filteredArticles.slice(1, 4);
  const wireArticles = filteredArticles.slice(4);

  const formatTime = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString(isTe ? 'te-IN' : 'en-IN', {
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return '';
    }
  };

  const renderFallbackArt = (article: NewsArticle) => (
    <div className="w-full h-full bg-gradient-to-br from-[#1E3A8A]/90 via-slate-800 to-stone-900 flex flex-col justify-end p-5 text-white">
      <span className="text-xs font-medium text-stone-300">
        {CATEGORY_LABELS[article.category][lang]}
      </span>
      <p className="font-display text-base font-medium mt-1 line-clamp-2">
        {article.title[lang]}
      </p>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Breaking News Ticker */}
      <div className="border border-stone-200 dark:border-slate-800 bg-white dark:bg-[#111827] rounded-xl overflow-hidden flex items-center">
        <div className="px-4 py-2.5 bg-[#1E3A8A] dark:bg-[#1D4ED8] text-white text-xs font-semibold tracking-wide whitespace-nowrap shrink-0">
          {isTe ? 'తాజా బ్రేకింగ్' : 'Breaking Wire'}
        </div>
        <div className="flex-1 overflow-hidden ticker-wrapper py-2.5 px-4">
          <div className={`ticker-track ${tickerPaused ? 'paused' : ''}`}>
            {[...tickerItems, ...tickerItems].map((item, idx) => (
              <button
                key={`${item.id}-${idx}`}
                type="button"
                onClick={() => setSelectedArticle(item)}
                className="inline-flex items-center gap-3 mr-10 text-sm text-stone-800 dark:text-slate-200 hover:text-[#1E3A8A] dark:hover:text-[#38BDF8] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span className="text-xs font-medium text-stone-500 dark:text-slate-400">
                  {CATEGORY_LABELS[item.category][lang]}
                </span>
                <span aria-hidden="true" className="text-stone-300 dark:text-slate-600">
                  /
                </span>
                <span className="font-medium">{item.title[lang]}</span>
              </button>
            ))}
          </div>
        </div>
        <button
          type="button"
          onClick={() => setTickerPaused((p) => !p)}
          aria-label={tickerPaused ? 'Resume ticker' : 'Pause ticker'}
          className="px-3.5 py-2.5 border-l border-stone-200 dark:border-slate-800 text-stone-600 dark:text-slate-300 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors shrink-0 cursor-pointer"
        >
          {tickerPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
        </button>
      </div>

      {/* Category Filter Bar + Live Sync Action */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
          {(Object.keys(CATEGORY_LABELS) as NewsCategory[]).map((cat) => {
            const active = activeCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => onSelectCategory(cat)}
                className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-[#1E3A8A] dark:bg-[#2563EB] text-white'
                    : 'bg-stone-100 dark:bg-slate-800/80 text-stone-700 dark:text-slate-300 hover:bg-stone-200 dark:hover:bg-slate-700'
                }`}
              >
                {CATEGORY_LABELS[cat][lang]}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => onSelectCategory('saved')}
            className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeCategory === 'saved'
                ? 'bg-[#1E3A8A] dark:bg-[#2563EB] text-white'
                : 'bg-stone-100 dark:bg-slate-800/80 text-stone-700 dark:text-slate-300 hover:bg-stone-200 dark:hover:bg-slate-700'
            }`}
          >
            {isTe ? `సేవ్ చేసినవి (${bookmarkedIds.length})` : `Saved (${bookmarkedIds.length})`}
          </button>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <span className="font-mono-tabular text-xs text-stone-500 dark:text-slate-400">
            {isTe ? 'సమకాలీకరణ:' : 'Synced:'}{' '}
            {new Date(lastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
          <button
            type="button"
            onClick={onRefreshLive}
            disabled={refreshing}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-stone-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-xs font-medium text-stone-800 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span>
              {refreshing
                ? isTe
                  ? 'నవీకరిస్తోంది...'
                  : 'Fetching Live...'
                : isTe
                  ? 'తాజా వార్తలు పొందండి'
                  : 'Sync Live Updates'}
            </span>
          </button>
        </div>
      </div>

      {refreshError && (
        <div
          role="alert"
          className="p-3.5 rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 text-sm text-amber-900 dark:text-amber-200"
        >
          {refreshError}
        </div>
      )}

      {/* Empty State */}
      {filteredArticles.length === 0 ? (
        <div className="py-16 text-center border border-stone-200 dark:border-slate-800 rounded-xl bg-white dark:bg-[#111827]">
          <p className="font-display text-xl font-medium text-stone-900 dark:text-white">
            {isTe ? 'సరిపోయే వార్తలు కనుగొనబడలేదు' : 'No matching current affairs found'}
          </p>
          <p className="text-sm text-stone-500 dark:text-slate-400 mt-2">
            {isTe
              ? 'మీ శోధన పదాన్ని మార్చండి లేదా "అన్ని వార్తలు" వర్గాన్ని ఎంచుకోండి.'
              : 'Try adjusting your search query or switching back to All Briefings.'}
          </p>
        </div>
      ) : (
        <div className="space-y-10">
          {/* Tier 1: Lead Editorial Feature */}
          {leadArticle && (
            <article className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl overflow-hidden">
              <div className="lg:col-span-6 min-h-[260px] lg:min-h-[360px] bg-stone-900 relative">
                {leadArticle.imageUrl && !brokenImages[leadArticle.id] ? (
                  <img
                    src={leadArticle.imageUrl}
                    alt={leadArticle.title[lang]}
                    referrerPolicy="no-referrer"
                    onError={() => setBrokenImages((prev) => ({ ...prev, [leadArticle.id]: true }))}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  renderFallbackArt(leadArticle)
                )}
              </div>
              <div className="lg:col-span-6 p-6 sm:p-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center flex-wrap gap-2 text-xs text-stone-500 dark:text-slate-400 mb-3">
                    <span className="font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
                      {CATEGORY_LABELS[leadArticle.category][lang]}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{formatTime(leadArticle.publishedAt)}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tabular">
                      {leadArticle.readMinutes} {isTe ? 'నిమిషాల చదువు' : 'min read'}
                    </span>
                  </div>

                  <h2
                    onClick={() => setSelectedArticle(leadArticle)}
                    className="font-display text-2xl sm:text-3xl font-semibold leading-snug text-stone-900 dark:text-white hover:text-[#1E3A8A] dark:hover:text-[#38BDF8] transition-colors cursor-pointer"
                  >
                    {leadArticle.title[lang]}
                  </h2>

                  <p className="mt-4 text-base text-stone-600 dark:text-slate-300 leading-relaxed">
                    {leadArticle.summary[lang]}
                  </p>

                  <p className="mt-4 pt-4 border-t border-stone-200 dark:border-slate-800 text-xs text-stone-600 dark:text-slate-400">
                    <span className="font-semibold text-stone-800 dark:text-slate-200">
                      {isTe ? 'పరీక్షా ప్రాముఖ్యత: ' : 'Exam Relevance: '}
                    </span>
                    {leadArticle.examRelevance[lang]}
                  </p>
                </div>

                <div className="mt-6 flex items-center justify-between gap-4">
                  <button
                    type="button"
                    onClick={() => setSelectedArticle(leadArticle)}
                    className="px-4 py-2 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-sm font-medium transition-colors cursor-pointer"
                  >
                    {isTe ? 'పూర్తి విశ్లేషణ చదవండి' : 'Read Full Briefing'}
                  </button>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onAskTutorAboutArticle(leadArticle)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-stone-200 dark:border-slate-700 text-xs font-medium text-stone-700 dark:text-slate-300 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    >
                      <Bot className="w-3.5 h-3.5" />
                      <span>{isTe ? 'AI వివరణ' : 'Ask Tutor'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleBookmark(leadArticle.id)}
                      aria-label="Toggle bookmark"
                      className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-stone-200 dark:border-slate-700 text-stone-700 dark:text-slate-300 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    >
                      {bookmarkedIds.includes(leadArticle.id) ? (
                        <BookmarkCheck className="w-4 h-4 text-[#1E3A8A] dark:text-[#38BDF8]" />
                      ) : (
                        <Bookmark className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </article>
          )}

          {/* Tier 2: Secondary Features Grid */}
          {secondaryArticles.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {secondaryArticles.map((article) => (
                <article
                  key={article.id}
                  className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col justify-between"
                >
                  <div>
                    <div className="aspect-[4/3] bg-stone-900 overflow-hidden">
                      {article.imageUrl && !brokenImages[article.id] ? (
                        <img
                          src={article.imageUrl}
                          alt={article.title[lang]}
                          referrerPolicy="no-referrer"
                          onError={() => setBrokenImages((prev) => ({ ...prev, [article.id]: true }))}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        renderFallbackArt(article)
                      )}
                    </div>
                    <div className="p-5">
                      <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-slate-400 mb-2">
                        <span className="font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
                          {CATEGORY_LABELS[article.category][lang]}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{formatTime(article.publishedAt)}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono-tabular">{article.readMinutes}m</span>
                      </div>
                      <h3
                        onClick={() => setSelectedArticle(article)}
                        className="font-display text-lg font-semibold leading-snug text-stone-900 dark:text-white hover:text-[#1E3A8A] dark:hover:text-[#38BDF8] transition-colors cursor-pointer"
                      >
                        {article.title[lang]}
                      </h3>
                      <p className="mt-2.5 text-sm text-stone-600 dark:text-slate-300 leading-relaxed line-clamp-3">
                        {article.summary[lang]}
                      </p>
                    </div>
                  </div>
                  <div className="px-5 py-3.5 border-t border-stone-100 dark:border-slate-800 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedArticle(article)}
                      className="text-xs font-semibold text-[#1E3A8A] dark:text-[#38BDF8] hover:underline cursor-pointer"
                    >
                      {isTe ? 'వివరాలు చూడండి' : 'Open Briefing'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleBookmark(article.id)}
                      aria-label="Toggle bookmark"
                      className="p-1.5 rounded-md text-stone-500 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    >
                      {bookmarkedIds.includes(article.id) ? (
                        <BookmarkCheck className="w-4 h-4 text-[#1E3A8A] dark:text-[#38BDF8]" />
                      ) : (
                        <Bookmark className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}

          {/* Tier 3: Department Wire / Archive List */}
          {wireArticles.length > 0 && (
            <section className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8">
              <h3 className="font-display text-xl font-semibold text-stone-900 dark:text-white mb-5">
                {isTe ? 'మరిన్ని ముఖ్యమైన అంశాలు' : 'Additional Exam Wire & Briefings'}
              </h3>
              <div className="divide-y divide-stone-200 dark:divide-slate-800">
                {wireArticles.map((article) => (
                  <div
                    key={article.id}
                    className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-slate-400">
                        <span className="font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
                          {CATEGORY_LABELS[article.category][lang]}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{formatTime(article.publishedAt)}</span>
                        <span aria-hidden="true">·</span>
                        <span>{article.examTags.join(' / ')}</span>
                      </div>
                      <h4
                        onClick={() => setSelectedArticle(article)}
                        className="font-display text-lg font-medium text-stone-900 dark:text-white hover:text-[#1E3A8A] dark:hover:text-[#38BDF8] transition-colors cursor-pointer"
                      >
                        {article.title[lang]}
                      </h4>
                      <p className="text-sm text-stone-600 dark:text-slate-400 max-w-3xl">
                        {article.summary[lang]}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setSelectedArticle(article)}
                        className="px-3.5 py-2 rounded-lg border border-stone-200 dark:border-slate-700 text-xs font-medium text-stone-700 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        {isTe ? 'చదవండి' : 'Read'}
                      </button>
                      <button
                        type="button"
                        onClick={() => onToggleBookmark(article.id)}
                        aria-label="Toggle bookmark"
                        className="p-2 rounded-lg border border-stone-200 dark:border-slate-700 text-stone-600 dark:text-slate-300 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        {bookmarkedIds.includes(article.id) ? (
                          <BookmarkCheck className="w-4 h-4 text-[#1E3A8A] dark:text-[#38BDF8]" />
                        ) : (
                          <Bookmark className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      )}

      {/* Article Detail Reader Modal */}
      {selectedArticle && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setSelectedArticle(null);
            }
          }}
        >
          <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl shadow-xl">
            <div className="sticky top-0 z-10 bg-white/95 dark:bg-[#111827]/95 backdrop-blur-sm border-b border-stone-200 dark:border-slate-800 px-6 py-4 flex items-center justify-between gap-4">
              <div className="text-xs text-stone-500 dark:text-slate-400">
                <span className="font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
                  {CATEGORY_LABELS[selectedArticle.category][lang]}
                </span>
                <span className="mx-2" aria-hidden="true">
                  ·
                </span>
                <span>{selectedArticle.examTags.join(' / ')}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setReaderMode((m) => (m === 'active' ? 'both' : 'active'))}
                  className="px-3 py-1.5 rounded-lg border border-stone-200 dark:border-slate-700 text-xs font-medium text-stone-700 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  {readerMode === 'both'
                    ? isTe
                      ? 'ఒకే భాషలో చూడండి'
                      : 'Single Language'
                    : isTe
                      ? 'ఇంగ్లీష్ + తెలుగు చూడండి'
                      : 'Compare English & Telugu'}
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedArticle(null)}
                  aria-label="Close reader"
                  className="p-1.5 rounded-lg text-stone-500 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-6">
              {readerMode === 'both' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <div className="text-xs font-semibold text-stone-500 dark:text-slate-400">
                      English Edition
                    </div>
                    <h2 className="font-display text-2xl font-semibold text-stone-900 dark:text-white leading-snug">
                      {selectedArticle.title.en}
                    </h2>
                    <p className="text-sm text-stone-700 dark:text-slate-300 leading-relaxed">
                      {selectedArticle.body.en}
                    </p>
                    <div className="p-3.5 rounded-lg bg-[#F3EFE6] dark:bg-slate-800/70 text-xs text-stone-700 dark:text-slate-300">
                      <span className="font-semibold block mb-1">Exam Relevance</span>
                      {selectedArticle.examRelevance.en}
                    </div>
                  </div>
                  <div className="space-y-3 md:border-l md:border-stone-200 dark:md:border-slate-800 md:pl-6">
                    <div className="text-xs font-semibold text-stone-500 dark:text-slate-400">
                      తెలుగు ఎడిషన్
                    </div>
                    <h2 className="font-display text-2xl font-semibold text-stone-900 dark:text-white leading-snug">
                      {selectedArticle.title.te}
                    </h2>
                    <p className="text-sm text-stone-700 dark:text-slate-300 leading-relaxed">
                      {selectedArticle.body.te}
                    </p>
                    <div className="p-3.5 rounded-lg bg-[#F3EFE6] dark:bg-slate-800/70 text-xs text-stone-700 dark:text-slate-300">
                      <span className="font-semibold block mb-1">పరీక్షా ప్రాముఖ్యత</span>
                      {selectedArticle.examRelevance.te}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 max-w-prose">
                  <h2 className="font-display text-2xl sm:text-3xl font-semibold text-stone-900 dark:text-white leading-snug">
                    {selectedArticle.title[lang]}
                  </h2>
                  <p className="text-base text-stone-700 dark:text-slate-300 leading-relaxed">
                    {selectedArticle.summary[lang]}
                  </p>
                  <p className="text-base text-stone-700 dark:text-slate-300 leading-relaxed">
                    {selectedArticle.body[lang]}
                  </p>
                  <div className="p-4 rounded-lg bg-[#F3EFE6] dark:bg-slate-800/70 border border-stone-200 dark:border-slate-700 text-sm text-stone-800 dark:text-slate-200">
                    <span className="font-semibold block mb-1">
                      {isTe ? 'పరీక్షా సిలబస్ లింక్' : 'Exam Syllabus Mapping'}
                    </span>
                    {selectedArticle.examRelevance[lang]}
                  </div>
                </div>
              )}

              {selectedArticle.sources.length > 0 && (
                <div className="pt-4 border-t border-stone-200 dark:border-slate-800">
                  <div className="text-xs font-semibold text-stone-500 dark:text-slate-400 mb-2">
                    {isTe ? 'ఆధారాలు & వనరులు' : 'Reference Sources'}
                  </div>
                  <div className="flex flex-wrap gap-4">
                    {selectedArticle.sources.map((src, i) => {
                      const safeUrl = safeExternalHref(src.url);
                      if (!safeUrl) return null;
                      return (
                        <a
                          key={i}
                          href={safeUrl}
                          target="_blank"
                          rel="noopener noreferrer nofollow"
                          className="inline-flex items-center gap-1.5 text-xs font-medium text-[#1E3A8A] dark:text-[#38BDF8] hover:underline"
                        >
                          <span>{src.title}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="pt-4 border-t border-stone-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const art = selectedArticle;
                    setSelectedArticle(null);
                    onAskTutorAboutArticle(art);
                  }}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-sm font-medium transition-colors cursor-pointer"
                >
                  <Bot className="w-4 h-4" />
                  <span>
                    {isTe
                      ? 'ఈ అంశంపై AI ట్యూటర్‌తో చర్చించండి'
                      : 'Ask AI Tutor for Exam Notes'}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => onToggleBookmark(selectedArticle.id)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-stone-300 dark:border-slate-700 text-sm font-medium text-stone-700 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  {bookmarkedIds.includes(selectedArticle.id) ? (
                    <>
                      <BookmarkCheck className="w-4 h-4 text-[#1E3A8A] dark:text-[#38BDF8]" />
                      <span>{isTe ? 'సేవ్ చేయబడింది' : 'Saved'}</span>
                    </>
                  ) : (
                    <>
                      <Bookmark className="w-4 h-4" />
                      <span>{isTe ? 'తర్వాత కోసం సేవ్ చేయండి' : 'Save for Revision'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
