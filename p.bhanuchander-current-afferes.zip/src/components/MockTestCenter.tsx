import React, { useEffect, useState } from 'react';
import { Award, CheckCircle2, Clock, Sparkles, XCircle } from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { Language, MockTestDeck, QuizAttempt, StudentProfile } from '../types';

interface MockTestCenterProps {
  lang: Language;
  decks: MockTestDeck[];
  onAddDeck: (deck: MockTestDeck) => void;
  attempts: QuizAttempt[];
  onAttemptSaved: (student: StudentProfile) => void;
}

export const MockTestCenter: React.FC<MockTestCenterProps> = ({
  lang,
  decks,
  onAddDeck,
  attempts,
  onAttemptSaved,
}) => {
  const [activeDeck, setActiveDeck] = useState<MockTestDeck | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  const [genTrack, setGenTrack] = useState('UPSC Civil Services Prelims');
  const [genTopic, setGenTopic] = useState('');
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState('');

  const isTe = lang === 'te';

  useEffect(() => {
    if (!activeDeck || submitted || secondsLeft <= 0) return;
    const timer = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [activeDeck, submitted, secondsLeft]);

  const startDeck = (deck: MockTestDeck) => {
    setActiveDeck(deck);
    setCurrentIdx(0);
    setAnswers({});
    setSecondsLeft(deck.durationMinutes * 60);
    setSubmitted(false);
  };

  const handleSubmitTest = async () => {
    if (!activeDeck || submitted) return;
    setSubmitted(true);

    let correctCount = 0;
    let wrongCount = 0;
    activeDeck.questions.forEach((q) => {
      const picked = answers[q.id];
      if (picked === q.correctIndex) {
        correctCount += 1;
      } else if (typeof picked === 'number') {
        wrongCount += 1;
      }
    });

    const totalQ = Math.max(1, activeDeck.questions.length);
    const maxScore = totalQ * activeDeck.positiveMarks;
    const rawScore =
      correctCount * activeDeck.positiveMarks - wrongCount * activeDeck.negativeMarks;
    const score = Math.max(0, Math.round(rawScore * 100) / 100);
    const accuracyPercent = Math.round((correctCount / totalQ) * 100);

    try {
      const res = await apiFetch<{ student: StudentProfile }>('/api/progress/quiz', {
        method: 'POST',
        body: JSON.stringify({
          deckId: activeDeck.id,
          deckTitle: activeDeck.title[lang],
          examTrack: activeDeck.examTrack,
          score,
          maxScore,
          accuracyPercent,
          correctCount,
          totalQuestions: activeDeck.questions.length,
        }),
      });
      onAttemptSaved(res.student);
    } catch {
      // Score still renders in review screen even if network hiccups
    }
  };

  useEffect(() => {
    if (activeDeck && !submitted && secondsLeft === 0) {
      void handleSubmitTest();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondsLeft, activeDeck, submitted]);

  const handleGenerateMock = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenError('');
    setGenerating(true);
    try {
      const res = await apiFetch<{ deck: MockTestDeck }>('/api/quiz/generate', {
        method: 'POST',
        body: JSON.stringify({
          examTrack: genTrack,
          topic: genTopic.trim() || 'Recent National, Regional & Economic Current Affairs',
        }),
      });
      onAddDeck(res.deck);
      startDeck(res.deck);
      setGenTopic('');
    } catch (err) {
      setGenError(err instanceof Error ? err.message : 'Unable to generate mock test.');
    } finally {
      setGenerating(false);
    }
  };

  const formatClock = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  if (activeDeck) {
    const q = activeDeck.questions[currentIdx];
    const correctCount = activeDeck.questions.filter((item) => answers[item.id] === item.correctIndex).length;
    const wrongCount = activeDeck.questions.filter(
      (item) => typeof answers[item.id] === 'number' && answers[item.id] !== item.correctIndex
    ).length;
    const score = Math.max(
      0,
      Math.round(
        (correctCount * activeDeck.positiveMarks - wrongCount * activeDeck.negativeMarks) * 100
      ) / 100
    );
    const maxScore = activeDeck.questions.length * activeDeck.positiveMarks;

    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-medium text-stone-500 dark:text-slate-400">
              {activeDeck.examTrack} · +{activeDeck.positiveMarks} / -{activeDeck.negativeMarks}
            </div>
            <h2 className="font-display text-xl font-semibold text-stone-900 dark:text-white mt-0.5">
              {activeDeck.title[lang]}
            </h2>
          </div>
          <div className="flex items-center gap-3">
            {!submitted ? (
              <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg border border-stone-200 dark:border-slate-700 bg-[#FBF9F5] dark:bg-[#0B1120] font-mono-tabular text-sm font-semibold text-stone-900 dark:text-white">
                <Clock className="w-4 h-4 text-[#1E3A8A] dark:text-[#38BDF8]" />
                <span>{formatClock(secondsLeft)}</span>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => startDeck(activeDeck)}
                className="px-3.5 py-2 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-xs font-medium transition-colors cursor-pointer"
              >
                {isTe ? 'మళ్ళీ రాయండి' : 'Retake Test'}
              </button>
            )}
            <button
              type="button"
              onClick={() => setActiveDeck(null)}
              className="px-3.5 py-2 rounded-lg border border-stone-300 dark:border-slate-700 text-xs font-medium text-stone-700 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              {isTe ? 'పరీక్షల జాబితాకు వెళ్ళండి' : 'Back to Tests'}
            </button>
          </div>
        </div>

        {submitted ? (
          <div className="space-y-6">
            <div className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 grid grid-cols-2 sm:grid-cols-4 gap-6">
              <div>
                <div className="text-xs text-stone-500 dark:text-slate-400">
                  {isTe ? 'మొత్తం స్కోరు' : 'Final Score'}
                </div>
                <div className="font-mono-tabular text-2xl font-semibold text-[#1E3A8A] dark:text-[#38BDF8] mt-1">
                  {score} / {maxScore}
                </div>
              </div>
              <div>
                <div className="text-xs text-stone-500 dark:text-slate-400">
                  {isTe ? 'సరైన సమాధానాలు' : 'Correct'}
                </div>
                <div className="font-mono-tabular text-2xl font-semibold text-emerald-700 dark:text-emerald-400 mt-1">
                  {correctCount} / {activeDeck.questions.length}
                </div>
              </div>
              <div>
                <div className="text-xs text-stone-500 dark:text-slate-400">
                  {isTe ? 'తప్పు సమాధానాలు' : 'Incorrect'}
                </div>
                <div className="font-mono-tabular text-2xl font-semibold text-red-700 dark:text-red-400 mt-1">
                  {wrongCount}
                </div>
              </div>
              <div>
                <div className="text-xs text-stone-500 dark:text-slate-400">
                  {isTe ? 'ఖచ్చితత్వం' : 'Accuracy'}
                </div>
                <div className="font-mono-tabular text-2xl font-semibold text-stone-900 dark:text-white mt-1">
                  {Math.round((correctCount / activeDeck.questions.length) * 100)}%
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {activeDeck.questions.map((item, idx) => {
                const picked = answers[item.id];
                const isCorrect = picked === item.correctIndex;
                return (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <h3 className="font-medium text-base text-stone-900 dark:text-white">
                        {idx + 1}. {item.question[lang]}
                      </h3>
                      <span
                        className={`inline-flex items-center gap-1 text-xs font-semibold shrink-0 ${
                          isCorrect
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-red-700 dark:text-red-400'
                        }`}
                      >
                        {isCorrect ? (
                          <>
                            <CheckCircle2 className="w-4 h-4" />
                            <span>{isTe ? 'సరైనది' : 'Correct'}</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-4 h-4" />
                            <span>{isTe ? 'తప్పు / వదిలారు' : 'Missed'}</span>
                          </>
                        )}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {item.options.map((opt, optIdx) => {
                        const isRightOpt = optIdx === item.correctIndex;
                        const isPickedOpt = optIdx === picked;
                        let style =
                          'border-stone-200 dark:border-slate-800 bg-[#FBF9F5] dark:bg-[#0B1120] text-stone-700 dark:text-slate-300';
                        if (isRightOpt) {
                          style =
                            'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-medium';
                        } else if (isPickedOpt && !isRightOpt) {
                          style =
                            'border-red-400 bg-red-50 dark:bg-red-950/40 text-red-900 dark:text-red-200';
                        }
                        return (
                          <div key={optIdx} className={`px-4 py-2.5 rounded-lg border text-sm ${style}`}>
                            {String.fromCharCode(65 + optIdx)}. {opt[lang]}
                          </div>
                        );
                      })}
                    </div>

                    <div className="p-3.5 rounded-lg bg-[#F3EFE6] dark:bg-slate-800/70 text-xs text-stone-700 dark:text-slate-300 leading-relaxed">
                      <span className="font-semibold text-stone-900 dark:text-white mr-1">
                        {isTe ? 'వివరణ:' : 'Explanation:'}
                      </span>
                      {item.explanation[lang]}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Active Question Card */}
            <div className="lg:col-span-8 bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between text-xs text-stone-500 dark:text-slate-400">
                <span>
                  {isTe
                    ? `ప్రశ్న ${currentIdx + 1} / ${activeDeck.questions.length}`
                    : `Question ${currentIdx + 1} of ${activeDeck.questions.length}`}
                </span>
                <span>{q.examTrack}</span>
              </div>

              <h3 className="font-display text-xl sm:text-2xl font-medium text-stone-900 dark:text-white leading-snug">
                {q.question[lang]}
              </h3>

              <div className="space-y-3">
                {q.options.map((opt, optIdx) => {
                  const selected = answers[q.id] === optIdx;
                  return (
                    <button
                      key={optIdx}
                      type="button"
                      onClick={() => setAnswers((prev) => ({ ...prev, [q.id]: optIdx }))}
                      className={`w-full text-left px-4 py-3.5 rounded-lg border text-sm transition-colors flex items-center gap-3 cursor-pointer ${
                        selected
                          ? 'border-[#1E3A8A] dark:border-[#38BDF8] bg-[#1E3A8A]/5 dark:bg-[#38BDF8]/10 text-stone-900 dark:text-white font-medium'
                          : 'border-stone-200 dark:border-slate-800 bg-[#FBF9F5] dark:bg-[#0B1120] text-stone-700 dark:text-slate-300 hover:border-stone-400 dark:hover:border-slate-600'
                      }`}
                    >
                      <span
                        className={`w-7 h-7 rounded-md flex items-center justify-center font-mono-tabular text-xs font-semibold shrink-0 ${
                          selected
                            ? 'bg-[#1E3A8A] dark:bg-[#2563EB] text-white'
                            : 'bg-stone-200 dark:bg-slate-800 text-stone-700 dark:text-slate-300'
                        }`}
                      >
                        {String.fromCharCode(65 + optIdx)}
                      </span>
                      <span>{opt[lang]}</span>
                    </button>
                  );
                })}
              </div>

              <div className="pt-4 border-t border-stone-200 dark:border-slate-800 flex items-center justify-between gap-4">
                <button
                  type="button"
                  disabled={currentIdx === 0}
                  onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
                  className="px-4 py-2 rounded-lg border border-stone-300 dark:border-slate-700 text-sm font-medium text-stone-700 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 disabled:opacity-40 cursor-pointer"
                >
                  {isTe ? 'ముందు ప్రశ్న' : 'Previous'}
                </button>
                {currentIdx < activeDeck.questions.length - 1 ? (
                  <button
                    type="button"
                    onClick={() =>
                      setCurrentIdx((i) => Math.min(activeDeck.questions.length - 1, i + 1))
                    }
                    className="px-5 py-2 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-sm font-medium cursor-pointer"
                  >
                    {isTe ? 'తదుపరి ప్రశ్న' : 'Next Question'}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => void handleSubmitTest()}
                    className="px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-medium cursor-pointer"
                  >
                    {isTe ? 'పరీక్ష సమర్పించండి' : 'Submit Mock Test'}
                  </button>
                )}
              </div>
            </div>

            {/* Question Palette */}
            <aside className="lg:col-span-4 bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
              <div className="text-sm font-semibold text-stone-900 dark:text-white">
                {isTe ? 'ప్రశ్నల పట్టిక' : 'Question Navigator'}
              </div>
              <div className="grid grid-cols-5 gap-2">
                {activeDeck.questions.map((item, idx) => {
                  const answered = typeof answers[item.id] === 'number';
                  const isCurrent = idx === currentIdx;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setCurrentIdx(idx)}
                      className={`h-10 rounded-lg font-mono-tabular text-xs font-semibold border transition-colors cursor-pointer ${
                        isCurrent
                          ? 'border-[#1E3A8A] dark:border-[#38BDF8] ring-2 ring-[#1E3A8A]/20 dark:ring-[#38BDF8]/20'
                          : 'border-stone-200 dark:border-slate-700'
                      } ${
                        answered
                          ? 'bg-[#1E3A8A] dark:bg-[#2563EB] text-white'
                          : 'bg-[#FBF9F5] dark:bg-[#0B1120] text-stone-700 dark:text-slate-300'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
              <button
                type="button"
                onClick={() => void handleSubmitTest()}
                className="w-full py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 text-sm font-medium text-stone-800 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {isTe ? 'పరీక్ష ముగించి ఫలితం చూడండి' : 'Finish & Grade Now'}
              </button>
            </aside>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Custom AI Mock Test Generator */}
      <section className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8">
        <div className="max-w-3xl">
          <h2 className="font-display text-2xl font-semibold text-stone-900 dark:text-white">
            {isTe
              ? 'పోటీ పరీక్షల మాక్ టెస్ట్ & AI ప్రశ్నాపత్ర జనరేటర్'
              : 'Competitive Exam Mock Tests & AI Paper Generator'}
          </h2>
          <p className="text-sm text-stone-600 dark:text-slate-300 mt-1.5">
            {isTe
              ? 'UPSC, TSPSC / APPSC గ్రూప్ 1 & 2, SSC పరీక్షల కోసం సమయానుకూల ద్వైభాషా మాక్ టెస్టులను సాధన చేయండి లేదా కొత్త సెట్‌ను రూపొందించండి.'
              : 'Practice timed bilingual mock tests with negative marking or generate a fresh 5-question exam set tailored to your target syllabus.'}
          </p>
        </div>

        <form onSubmit={handleGenerateMock} className="mt-6 grid grid-cols-1 md:grid-cols-12 gap-3">
          <select
            value={genTrack}
            onChange={(e) => setGenTrack(e.target.value)}
            aria-label="Select Exam Track"
            className="md:col-span-4 px-3.5 py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-[#FBF9F5] dark:bg-[#0B1120] text-sm text-stone-900 dark:text-white"
          >
            <option value="UPSC Civil Services Prelims">UPSC Civil Services Prelims</option>
            <option value="TSPSC / APPSC Group 1 & 2">TSPSC / APPSC Group 1 & 2</option>
            <option value="SSC CGL / RRB / Banking">SSC CGL / RRB / Banking</option>
            <option value="Daily Current Affairs">Daily Current Affairs</option>
          </select>
          <input
            type="text"
            value={genTopic}
            onChange={(e) => setGenTopic(e.target.value)}
            placeholder={
              isTe
                ? 'అంశం నమోదు చేయండి (ఉదా: 16వ ఆర్థిక సంఘం, ఇస్రో, తెలంగాణ పథకాలు)'
                : 'Optional topic (e.g. RBI Policy, ISRO Missions, Telangana Economy)'
            }
            className="md:col-span-5 px-4 py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-[#FBF9F5] dark:bg-[#0B1120] text-sm text-stone-900 dark:text-white placeholder:text-stone-400"
          />
          <button
            type="submit"
            disabled={generating}
            className="md:col-span-3 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-sm font-medium transition-colors disabled:opacity-60 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>
              {generating
                ? isTe
                  ? 'రూపొందిస్తోంది...'
                  : 'Generating...'
                : isTe
                  ? 'కొత్త టెస్ట్ సృష్టించండి'
                  : 'Generate Mock Test'}
            </span>
          </button>
        </form>

        {genError && (
          <div
            role="alert"
            className="mt-4 p-3 rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 text-sm text-red-700 dark:text-red-300"
          >
            {genError}
          </div>
        )}
      </section>

      {/* Available Mock Test Decks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {decks.map((deck) => (
          <div
            key={deck.id}
            className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 flex flex-col justify-between gap-5"
          >
            <div>
              <div className="text-xs text-stone-500 dark:text-slate-400 mb-2">
                <span className="font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
                  {deck.examTrack}
                </span>
                <span className="mx-2" aria-hidden="true">
                  ·
                </span>
                <span className="font-mono-tabular">
                  {deck.questions.length} {isTe ? 'ప్రశ్నలు' : 'Questions'}
                </span>
                <span className="mx-2" aria-hidden="true">
                  ·
                </span>
                <span className="font-mono-tabular">
                  {deck.durationMinutes} {isTe ? 'నిమిషాలు' : 'Min'}
                </span>
              </div>
              <h3 className="font-display text-xl font-semibold text-stone-900 dark:text-white">
                {deck.title[lang]}
              </h3>
              <p className="text-xs text-stone-500 dark:text-slate-400 mt-2">
                {isTe
                  ? `మార్కులు: సరైన సమాధానానికి +${deck.positiveMarks}, తప్పుకు -${deck.negativeMarks}`
                  : `Marking scheme: +${deck.positiveMarks} correct, -${deck.negativeMarks} wrong`}
              </p>
            </div>
            <button
              type="button"
              onClick={() => startDeck(deck)}
              className="w-full py-2.5 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-sm font-medium transition-colors cursor-pointer"
            >
              {isTe ? 'మాక్ టెస్ట్ ప్రారంభించండి' : 'Start Timed Test'}
            </button>
          </div>
        ))}
      </div>

      {/* Saved Attempt History */}
      {attempts.length > 0 && (
        <section className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-5 h-5 text-[#1E3A8A] dark:text-[#38BDF8]" />
            <h3 className="font-display text-lg font-semibold text-stone-900 dark:text-white">
              {isTe ? 'మీ ఇటీవలి పరీక్ష ఫలితాలు' : 'Your Recorded Mock Test Results'}
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b border-stone-200 dark:border-slate-800 text-xs text-stone-500 dark:text-slate-400">
                  <th className="py-2.5 pr-4 font-medium">{isTe ? 'పరీక్ష' : 'Assessment'}</th>
                  <th className="py-2.5 pr-4 font-medium">{isTe ? 'విభాగం' : 'Track'}</th>
                  <th className="py-2.5 pr-4 font-medium">{isTe ? 'స్కోరు' : 'Score'}</th>
                  <th className="py-2.5 font-medium">{isTe ? 'ఖచ్చితత్వం' : 'Accuracy'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-slate-800/70">
                {attempts.slice(0, 8).map((att) => (
                  <tr key={att.id}>
                    <td className="py-3 pr-4 font-medium text-stone-900 dark:text-white">
                      {att.deckTitle}
                    </td>
                    <td className="py-3 pr-4 text-stone-600 dark:text-slate-400">{att.examTrack}</td>
                    <td className="py-3 pr-4 font-mono-tabular text-stone-900 dark:text-white">
                      {att.score} / {att.maxScore}
                    </td>
                    <td className="py-3 font-mono-tabular font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
                      {att.accuracyPercent}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
};
