import React, { useEffect, useState } from 'react';
import { ArrowRight, CheckCircle2, KeyRound, Languages, Mail, Moon, ShieldCheck, Sun, UserCheck } from 'lucide-react';
import { EDUCATION_LEVELS } from '../data/bilingualContent';
import { apiFetch, getDeviceTokenForEmail, setDeviceTokenForEmail, setStoredSessionToken } from '../lib/api';
import type { EducationLevel, Language, StudentProfile } from '../types';

interface AuthPortalProps {
  lang: Language;
  onToggleLang: () => void;
  darkMode: boolean;
  onToggleDark: () => void;
  onAuthenticated: (student: StudentProfile) => void;
}

interface LoginResponse {
  status: 'AUTHENTICATED' | 'OTP_REQUIRED';
  requiresOtp: boolean;
  student?: StudentProfile;
  sessionToken?: string;
  maskedEmail?: string;
  expiresInSeconds?: number;
  sandboxOtpPreview?: string;
}

interface VerifyResponse {
  status: 'AUTHENTICATED';
  student: StudentProfile;
  sessionToken: string;
  deviceToken: string;
}

export const AuthPortal: React.FC<AuthPortalProps> = ({
  lang,
  onToggleLang,
  darkMode,
  onToggleDark,
  onAuthenticated,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [educationLevel, setEducationLevel] = useState<EducationLevel>('UPSC Civil Services');
  const [step, setStep] = useState<'details' | 'otp'>('details');
  const [otp, setOtp] = useState('');
  const [maskedEmail, setMaskedEmail] = useState('');
  const [sandboxOtp, setSandboxOtp] = useState<string | undefined>(undefined);
  const [expiresCountdown, setExpiresCountdown] = useState(0);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [infoMsg, setInfoMsg] = useState('');
  const [imageFailed, setImageFailed] = useState(false);

  useEffect(() => {
    if (expiresCountdown <= 0) return;
    const timer = window.setInterval(() => {
      setExpiresCountdown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [expiresCountdown]);

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = window.setInterval(() => {
      setResendCooldown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [resendCooldown]);

  const handleDetailsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfoMsg('');
    setLoading(true);

    try {
      const normalizedEmail = email.trim().toLowerCase();
      const deviceToken = getDeviceTokenForEmail(normalizedEmail);
      const res = await apiFetch<LoginResponse>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          name: name.trim(),
          email: normalizedEmail,
          educationLevel,
          deviceToken,
        }),
      });

      if (!res.requiresOtp && res.student && res.sessionToken) {
        setStoredSessionToken(res.sessionToken);
        onAuthenticated(res.student);
        return;
      }

      setMaskedEmail(res.maskedEmail || normalizedEmail);
      setSandboxOtp(res.sandboxOtpPreview);
      setExpiresCountdown(res.expiresInSeconds || 300);
      setResendCooldown(15);
      setStep('otp');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to continue.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const normalizedEmail = email.trim().toLowerCase();
      const res = await apiFetch<VerifyResponse>('/api/auth/verify-otp', {
        method: 'POST',
        body: JSON.stringify({
          email: normalizedEmail,
          otp: otp.trim(),
        }),
      });

      setStoredSessionToken(res.sessionToken);
      setDeviceTokenForEmail(normalizedEmail, res.deviceToken);
      onAuthenticated(res.student);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid verification code.');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    if (resendCooldown > 0) return;
    setError('');
    setInfoMsg('');
    setLoading(true);

    try {
      const res = await apiFetch<LoginResponse>('/api/auth/request-otp', {
        method: 'POST',
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim().toLowerCase(),
          educationLevel,
        }),
      });
      setSandboxOtp(res.sandboxOtpPreview);
      setExpiresCountdown(res.expiresInSeconds || 300);
      setResendCooldown(15);
      setInfoMsg(
        lang === 'te'
          ? 'కొత్త 6-అంకెల ధృవీకరణ కోడ్ పంపబడింది.'
          : 'A fresh 6-digit verification passcode has been issued.'
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to resend passcode.');
    } finally {
      setLoading(false);
    }
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const isTe = lang === 'te';

  return (
    <div className="min-h-screen bg-[#FBF9F5] dark:bg-[#0B1120] text-[#1C1917] dark:text-[#F8FAFC] flex flex-col">
      {/* Top Minimal Utility Strip */}
      <header className="w-full border-b border-stone-200 dark:border-slate-800 bg-white/80 dark:bg-[#0F172A]/85 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-4">
          <div className="font-display text-lg sm:text-xl font-semibold tracking-tight whitespace-nowrap truncate">
            p.Bhanuchander current afferes
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onToggleLang}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-stone-200 dark:border-slate-700 bg-stone-50 dark:bg-slate-800 text-stone-800 dark:text-slate-100 hover:bg-stone-100 dark:hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{isTe ? 'English' : 'తెలుగు'}</span>
            </button>
            <button
              type="button"
              onClick={onToggleDark}
              aria-label="Toggle color theme"
              className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-stone-200 dark:border-slate-700 bg-stone-50 dark:bg-slate-800 text-stone-700 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-700 transition-colors shrink-0 cursor-pointer"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main 2-Column Editorial Auth Split */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-8 lg:py-12 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
        {/* Left: Pupil Access Form */}
        <section className="lg:col-span-6 flex flex-col justify-center">
          <div className="max-w-xl w-full mx-auto lg:mx-0">
            <p className="text-xs font-medium tracking-wide text-stone-500 dark:text-slate-400 mb-3">
              {isTe
                ? 'విద్యార్థుల పోర్టల్ · ద్వైభాషా కరెంట్ అఫైర్స్ & పోటీ పరీక్షల వేదిక'
                : 'Student Academic Portal · English & Telugu Bilingual Edition'}
            </p>
            <h1 className="font-display text-3xl sm:text-4xl lg:text-[2.65rem] font-semibold leading-[1.15] tracking-tight text-stone-900 dark:text-white mb-4">
              p.Bhanuchander current afferes
            </h1>
            <p className="text-base text-stone-600 dark:text-slate-300 leading-relaxed mb-8">
              {isTe
                ? 'ప్రాంతీయ, జాతీయ, అంతర్జాతీయ వార్తలు, మాక్ టెస్టులు, ఇన్ఫోగ్రాఫిక్స్ మరియు AI స్టడీ ట్యూటర్‌ను యాక్సెస్ చేయడానికి మీ వివరాలను నమోదు చేయండి. మొదటిసారి మాత్రమే OTP ధృవీకరణ అవసరం.'
                : 'Enter your student name, education level, and Gmail to unlock daily current affairs, competitive mock tests, infographics, and your AI study tutor. Initial login verifies once via OTP; subsequent logins stay seamlessly verified.'}
            </p>

            <div className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 shadow-sm">
              {step === 'details' ? (
                <form onSubmit={handleDetailsSubmit} className="space-y-5">
                  <div>
                    <label
                      htmlFor="pupil-name"
                      className="block text-sm font-medium text-stone-800 dark:text-slate-200 mb-1.5"
                    >
                      {isTe ? 'విద్యార్థి పేరు (Student User Name)' : 'Student Full Name'}
                    </label>
                    <input
                      id="pupil-name"
                      type="text"
                      required
                      minLength={2}
                      maxLength={80}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={isTe ? 'మీ పూర్తి పేరు నమోదు చేయండి' : 'Enter your full name'}
                      className="w-full px-4 py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-[#FBF9F5] dark:bg-[#0B1120] text-stone-900 dark:text-white placeholder:text-stone-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#1E3A8A] dark:focus:ring-[#38BDF8] transition-colors"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="education-level"
                      className="block text-sm font-medium text-stone-800 dark:text-slate-200 mb-1.5"
                    >
                      {isTe ? 'విద్యా స్థాయి (Education Level)' : 'Education Level / Exam Track'}
                    </label>
                    <select
                      id="education-level"
                      value={educationLevel}
                      onChange={(e) => setEducationLevel(e.target.value as EducationLevel)}
                      className="w-full px-4 py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-[#FBF9F5] dark:bg-[#0B1120] text-stone-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#1E3A8A] dark:focus:ring-[#38BDF8] transition-colors"
                    >
                      {EDUCATION_LEVELS.map((lvl) => (
                        <option key={lvl.value} value={lvl.value}>
                          {isTe ? lvl.te : lvl.en}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="pupil-email"
                      className="block text-sm font-medium text-stone-800 dark:text-slate-200 mb-1.5"
                    >
                      {isTe ? 'విద్యార్థి Gmail / ఈమెయిల్' : 'Student Gmail / Email Address'}
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-stone-400 dark:text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        id="pupil-email"
                        type="email"
                        required
                        maxLength={160}
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder={isTe ? 'మీ Gmail / ఈమెయిల్ నమోదు చేయండి' : 'Enter your Gmail address'}
                        className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-[#FBF9F5] dark:bg-[#0B1120] text-stone-900 dark:text-white placeholder:text-stone-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#1E3A8A] dark:focus:ring-[#38BDF8] transition-colors"
                      />
                    </div>
                  </div>

                  {error && (
                    <div
                      role="alert"
                      className="p-3 rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 text-sm text-red-700 dark:text-red-300"
                    >
                      {error}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white font-medium text-sm transition-colors disabled:opacity-60 cursor-pointer"
                  >
                    <span>
                      {loading
                        ? isTe
                          ? 'పరిశీలిస్తున్నాము...'
                          : 'Checking access...'
                        : isTe
                          ? 'పోర్టల్‌లోకి ప్రవేశించండి'
                          : 'Continue to Portal'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="pt-2 border-t border-stone-200 dark:border-slate-800 flex items-start gap-2.5 text-xs text-stone-500 dark:text-slate-400">
                    <ShieldCheck className="w-4 h-4 text-[#1E3A8A] dark:text-[#38BDF8] shrink-0 mt-0.5" />
                    <span>
                      {isTe
                        ? 'మొదటి లాగిన్ సమయంలో 6-అంకెల OTP ధృవీకరణ జరుగుతుంది. తర్వాత అదే పరికరంలో మళ్ళీ OTP అవసరం లేకుండా నేరుగా ప్రవేశించవచ్చు.'
                        : 'First-time access requires a single 6-digit OTP validation. Once verified on this device, future logins remain stable without repeat OTP prompts.'}
                    </span>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-5">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="font-display text-xl font-semibold text-stone-900 dark:text-white">
                        {isTe ? 'వన్-టైమ్ పాస్‌కోడ్ (OTP) ధృవీకరణ' : 'One-Time Passcode Validation'}
                      </h2>
                      <p className="text-sm text-stone-600 dark:text-slate-400 mt-1">
                        {isTe
                          ? `${maskedEmail} కు పంపిన 6-అంకెల కోడ్‌ను నమోదు చేయండి.`
                          : `Enter the 6-digit verification code issued for ${maskedEmail}.`}
                      </p>
                    </div>
                    <span className="font-mono-tabular text-xs font-medium text-stone-600 dark:text-slate-300 shrink-0">
                      {formatTimer(expiresCountdown)}
                    </span>
                  </div>

                  {sandboxOtp && (
                    <div className="p-3.5 rounded-lg border border-stone-200 dark:border-slate-700 bg-[#F3EFE6] dark:bg-slate-800/70">
                      <div className="flex items-center justify-between gap-3">
                        <div className="text-xs text-stone-700 dark:text-slate-300">
                          <span className="font-semibold block text-stone-900 dark:text-white">
                            {isTe ? 'Gmail OTP ప్రివ్యూ ఇన్‌బాక్స్' : 'Dispatched Gmail Passcode Preview'}
                          </span>
                          <span>
                            {isTe
                              ? 'ఈ సెషన్‌ను ధృవీకరించడానికి క్రింది కోడ్‌ను ఉపయోగించండి:'
                              : 'Use this server-generated one-time code to complete your initial verification:'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setOtp(sandboxOtp)}
                          className="font-mono-tabular text-lg font-semibold tracking-widest px-3 py-1.5 rounded-md bg-white dark:bg-slate-900 border border-stone-300 dark:border-slate-600 text-[#1E3A8A] dark:text-[#38BDF8] hover:border-[#1E3A8A] transition-colors shrink-0 cursor-pointer"
                          title="Click to fill passcode"
                        >
                          {sandboxOtp}
                        </button>
                      </div>
                    </div>
                  )}

                  <div>
                    <label
                      htmlFor="otp-input"
                      className="block text-sm font-medium text-stone-800 dark:text-slate-200 mb-1.5"
                    >
                      {isTe ? '6-అంకెల పాస్‌కోడ్' : '6-Digit Passcode'}
                    </label>
                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-stone-400 dark:text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        id="otp-input"
                        type="text"
                        inputMode="numeric"
                        pattern="\d{6}"
                        maxLength={6}
                        required
                        value={otp}
                        onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        placeholder="••••••"
                        className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-[#FBF9F5] dark:bg-[#0B1120] font-mono-tabular text-lg tracking-[0.35em] text-stone-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#1E3A8A] dark:focus:ring-[#38BDF8]"
                      />
                    </div>
                  </div>

                  {error && (
                    <div
                      role="alert"
                      className="p-3 rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 text-sm text-red-700 dark:text-red-300"
                    >
                      {error}
                    </div>
                  )}

                  {infoMsg && (
                    <div className="p-3 rounded-lg border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50 dark:bg-emerald-950/40 text-sm text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>{infoMsg}</span>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      type="submit"
                      disabled={loading || otp.length !== 6}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white font-medium text-sm transition-colors disabled:opacity-60 cursor-pointer"
                    >
                      <UserCheck className="w-4 h-4" />
                      <span>{loading ? (isTe ? 'ధృవీకరిస్తోంది...' : 'Verifying...') : isTe ? 'ధృవీకరించి ప్రవేశించండి' : 'Verify & Unlock Portal'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setStep('details');
                        setOtp('');
                        setError('');
                      }}
                      className="px-4 py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 text-sm font-medium text-stone-700 dark:text-slate-300 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    >
                      {isTe ? 'వివరాలు మార్చండి' : 'Edit Details'}
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-stone-200 dark:border-slate-800 text-xs text-stone-500 dark:text-slate-400">
                    <span>
                      {isTe ? 'కోడ్ రాలేదా?' : "Didn't receive the passcode?"}
                    </span>
                    <button
                      type="button"
                      onClick={handleResendOtp}
                      disabled={resendCooldown > 0 || loading}
                      className="font-medium text-[#1E3A8A] dark:text-[#38BDF8] hover:underline disabled:opacity-50 cursor-pointer"
                    >
                      {resendCooldown > 0
                        ? isTe
                          ? `${resendCooldown}సె తర్వాత మళ్ళీ పంపండి`
                          : `Resend in ${resendCooldown}s`
                        : isTe
                          ? 'కొత్త OTP పంపండి'
                          : 'Resend Passcode'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </section>

        {/* Right: Editorial Photography & Curriculum Highlights */}
        <aside className="lg:col-span-6 flex flex-col">
          <div className="relative flex-1 min-h-[360px] lg:min-h-[540px] rounded-xl overflow-hidden border border-stone-200 dark:border-slate-800 bg-stone-900">
            {!imageFailed ? (
              <img
                src="/src/assets/images/hero_editorial_desk_1795003972396.jpg"
                alt="Bilingual English and Telugu Current Affairs study desk with constitutional notes"
                referrerPolicy="no-referrer"
                onError={() => setImageFailed(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-[#1E3A8A] via-slate-900 to-stone-900" />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8 text-white">
              <p className="text-xs font-medium text-stone-300 mb-2">
                {isTe
                  ? 'రోజువారీ పరీక్షల సంసిద్ధత · ప్రాంతీయ, జాతీయ, అంతర్జాతీయ వార్తలు'
                  : 'Daily Exam Readiness · Regional, National & Global Editions'}
              </p>
              <h2 className="font-display text-2xl sm:text-3xl font-semibold leading-snug text-white mb-4">
                {isTe
                  ? 'తెలుగు మరియు ఇంగ్లీష్‌లో సమగ్ర కరెంట్ అఫైర్స్ & మాక్ టెస్టులు'
                  : 'Structured Bilingual Briefings Built for Serious Exam Aspirants'}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-white/20 text-xs text-stone-200">
                <div>
                  <div className="font-semibold text-white">
                    {isTe ? 'ప్రతిరోజూ తాజా వార్తలు' : 'Regional to Global'}
                  </div>
                  <div className="text-stone-300 mt-0.5">
                    {isTe ? 'తెలంగాణ, ఏపీ, జాతీయ & ప్రపంచ' : 'TS, AP, National & World'}
                  </div>
                </div>
                <div>
                  <div className="font-semibold text-white">
                    {isTe ? 'సమయానుకూల మాక్ టెస్టులు' : 'Timed Mock Tests'}
                  </div>
                  <div className="text-stone-300 mt-0.5">
                    {isTe ? 'UPSC, Group-1 & 2, SSC' : 'UPSC, Group-1 & 2, SSC'}
                  </div>
                </div>
                <div>
                  <div className="font-semibold text-white">
                    {isTe ? 'AI ట్యూటర్ & పదకోశం' : 'AI Tutor & Glossary'}
                  </div>
                  <div className="text-stone-300 mt-0.5">
                    {isTe ? 'తక్షణ ద్వైభాషా వివరణలు' : 'Instant bilingual clarity'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
};
