import React, { useEffect, useRef, useState } from 'react';
import { BookMarked, Bot, ExternalLink, Globe2, Send } from 'lucide-react';
import { GLOSSARY_TERMS } from '../data/bilingualContent';
import { apiFetch } from '../lib/api';
import { safeExternalHref } from '../lib/security';
import type { GlossaryTerm, GroundedSource, Language, StudentProfile } from '../types';

interface GlossaryViewProps {
  lang: Language;
  searchQuery: string;
  onExplainTermWithAI: (term: GlossaryTerm) => void;
}

export const GlossaryView: React.FC<GlossaryViewProps> = ({
  lang,
  searchQuery,
  onExplainTermWithAI,
}) => {
  const [selectedCat, setSelectedCat] = useState<'All' | GlossaryTerm['category']>('All');
  const isTe = lang === 'te';

  const categories: Array<'All' | GlossaryTerm['category']> = [
    'All',
    'Polity',
    'Economy',
    'Science',
    'Environment',
    'International',
  ];

  const q = searchQuery.trim().toLowerCase();
  const filtered = GLOSSARY_TERMS.filter((item) => {
    if (selectedCat !== 'All' && item.category !== selectedCat) return false;
    if (!q) return true;
    const text = [
      item.term.en,
      item.term.te,
      item.definition.en,
      item.definition.te,
      item.examContext.en,
      item.examContext.te,
    ]
      .join(' ')
      .toLowerCase();
    return text.includes(q);
  });

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 space-y-5">
        <div className="flex items-start gap-3">
          <BookMarked className="w-5 h-5 text-[#1E3A8A] dark:text-[#38BDF8] mt-1 shrink-0" />
          <div>
            <h2 className="font-display text-2xl font-semibold text-stone-900 dark:text-white">
              {isTe
                ? 'క్లిష్టమైన పరీక్షా పదాల ద్వైభాషా పదకోశం'
                : 'Bilingual Glossary of Complex Terms'}
            </h2>
            <p className="text-sm text-stone-600 dark:text-slate-400 mt-1">
              {isTe
                ? 'ఆర్థిక, రాజ్యాంగ, సైన్స్ & అంతర్జాతీయ అంశాల్లోని కీలక పదాలను ఇంగ్లీష్ మరియు తెలుగులో సులభంగా అర్థం చేసుకోండి.'
                : 'Master high-yield economic, constitutional, scientific, and diplomatic terminology with English & Telugu definitions.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCat(cat)}
              className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedCat === cat
                  ? 'bg-[#1E3A8A] dark:bg-[#2563EB] text-white'
                  : 'bg-stone-100 dark:bg-slate-800 text-stone-700 dark:text-slate-300 hover:bg-stone-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="py-12 text-center bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl text-sm text-stone-500 dark:text-slate-400">
          {isTe ? 'సరిపోయే పదాలు కనుగొనబడలేదు.' : 'No glossary terms match your search.'}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((item) => (
            <article
              key={item.id}
              className="bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 flex flex-col justify-between gap-4"
            >
              <div className="space-y-3">
                <div className="text-xs font-semibold text-[#1E3A8A] dark:text-[#38BDF8]">
                  {item.category}
                </div>
                <div>
                  <h3 className="font-display text-xl font-semibold text-stone-900 dark:text-white">
                    {item.term[lang]}
                  </h3>
                  <div className="text-xs text-stone-500 dark:text-slate-400 mt-0.5">
                    {lang === 'en' ? item.term.te : item.term.en}
                  </div>
                </div>
                <p className="text-sm text-stone-700 dark:text-slate-300 leading-relaxed">
                  {item.definition[lang]}
                </p>
                <div className="p-3.5 rounded-lg bg-[#F3EFE6] dark:bg-slate-800/70 text-xs text-stone-700 dark:text-slate-300 leading-relaxed">
                  <span className="font-semibold text-stone-900 dark:text-white mr-1">
                    {isTe ? 'పరీక్షా కోణం:' : 'Exam Context:'}
                  </span>
                  {item.examContext[lang]}
                </div>
              </div>
              <div className="pt-2 border-t border-stone-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => onExplainTermWithAI(item)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1E3A8A] dark:text-[#38BDF8] hover:underline cursor-pointer"
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>
                    {isTe
                      ? 'AI ట్యూటర్‌తో ఉదాహరణలు తెలుసుకోండి'
                      : 'Ask AI Tutor for Examples'}
                  </span>
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};

interface TutorMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  sources?: GroundedSource[];
}

interface AiTutorViewProps {
  lang: Language;
  student: StudentProfile;
  prefilledPrompt: string;
  onClearPrefill: () => void;
}

export const AiTutorView: React.FC<AiTutorViewProps> = ({
  lang,
  student,
  prefilledPrompt,
  onClearPrefill,
}) => {
  const [messages, setMessages] = useState<TutorMessage[]>([]);
  const [input, setInput] = useState('');
  const [responseLang, setResponseLang] = useState<'bilingual' | 'en' | 'te'>('bilingual');
  const [useWebSearch, setUseWebSearch] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const isTe = lang === 'te';

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, loading]);

  const sendQuestion = async (questionText: string) => {
    const trimmed = questionText.trim();
    if (!trimmed || loading) return;

    setError('');
    const userMsg: TutorMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: trimmed,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await apiFetch<{ answer: string; sources?: GroundedSource[] }>(
        '/api/assistant/ask',
        {
          method: 'POST',
          body: JSON.stringify({
            question: trimmed,
            language: responseLang,
            useWebSearch,
          }),
        }
      );

      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          role: 'assistant',
          text: res.answer,
          sources: res.sources,
        },
      ]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach AI Study Assistant.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (prefilledPrompt) {
      void sendQuestion(prefilledPrompt);
      onClearPrefill();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefilledPrompt]);

  const starterPrompts = isTe
    ? [
        '16వ ఆర్థిక సంఘం & ఆర్టికల్ 280 గురించి ప్రధాన పరీక్షా పాయింట్లు వివరించండి',
        'తెలంగాణ, ఆంధ్రప్రదేశ్ పారిశ్రామిక కారిడార్ల ప్రాముఖ్యతను వివరించండి',
        'భారతదేశంలో డిజిటల్ పబ్లిక్ ఇన్‌ఫ్రాస్ట్రక్చర్ (DPI) ఉదాహరణలతో చెప్పండి',
      ]
    : [
        'Summarize 5 high-yield UPSC Prelims takeaways from today’s Indian Economy news',
        'Explain Fiscal Federalism & Article 280 in both English and Telugu',
        'What is Quantum Key Distribution (QKD) and why does it matter for India?',
      ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left Configuration & Quick Starters */}
      <aside className="lg:col-span-4 bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex items-start gap-3">
          <Bot className="w-5 h-5 text-[#1E3A8A] dark:text-[#38BDF8] mt-0.5 shrink-0" />
          <div>
            <h2 className="font-display text-xl font-semibold text-stone-900 dark:text-white">
              {isTe ? 'AI స్టడీ ట్యూటర్' : 'Bilingual AI Study Assistant'}
            </h2>
            <p className="text-xs text-stone-500 dark:text-slate-400 mt-1">
              {student.name} · {student.educationLevel}
            </p>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-medium text-stone-700 dark:text-slate-300">
            {isTe ? 'సమాధానం భాష' : 'Assistant Output Language'}
          </label>
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-stone-100 dark:bg-slate-800 rounded-lg">
            {[
              { id: 'bilingual' as const, label: 'EN + తె' },
              { id: 'en' as const, label: 'English' },
              { id: 'te' as const, label: 'తెలుగు' },
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setResponseLang(opt.id)}
                className={`py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  responseLang === opt.id
                    ? 'bg-white dark:bg-slate-900 text-stone-900 dark:text-white shadow-xs'
                    : 'text-stone-600 dark:text-slate-400'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <label className="flex items-center gap-2.5 text-xs text-stone-700 dark:text-slate-300 cursor-pointer">
          <input
            type="checkbox"
            checked={useWebSearch}
            onChange={(e) => setUseWebSearch(e.target.checked)}
            className="rounded border-stone-300 dark:border-slate-700 text-[#1E3A8A]"
          />
          <Globe2 className="w-4 h-4 text-[#1E3A8A] dark:text-[#38BDF8] shrink-0" />
          <span>
            {isTe
              ? 'తాజా సమాచారం కోసం Google శోధన ఉపయోగించండి'
              : 'Use live Google Search grounding'}
          </span>
        </label>

        <div className="pt-4 border-t border-stone-200 dark:border-slate-800 space-y-2.5">
          <div className="text-xs font-semibold text-stone-500 dark:text-slate-400">
            {isTe ? 'త్వరిత పరీక్షా ప్రశ్నలు' : 'Quick Study Prompts'}
          </div>
          {starterPrompts.map((p, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => void sendQuestion(p)}
              className="w-full text-left p-3 rounded-lg border border-stone-200 dark:border-slate-800 bg-[#FBF9F5] dark:bg-[#0B1120] text-xs text-stone-700 dark:text-slate-300 hover:border-[#1E3A8A] dark:hover:border-[#38BDF8] transition-colors cursor-pointer"
            >
              {p}
            </button>
          ))}
        </div>
      </aside>

      {/* Right Chat Workspace */}
      <section className="lg:col-span-8 bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-800 rounded-xl flex flex-col min-h-[520px]">
        <div className="flex-1 p-6 space-y-5 overflow-y-auto max-h-[600px]">
          {messages.length === 0 ? (
            <div className="h-full min-h-[320px] flex flex-col items-center justify-center text-center max-w-md mx-auto">
              <Bot className="w-8 h-8 text-[#1E3A8A] dark:text-[#38BDF8] mb-3" />
              <h3 className="font-display text-xl font-semibold text-stone-900 dark:text-white">
                {isTe
                  ? `నమస్కారం ${student.name}! మీ సందేహాన్ని అడగండి.`
                  : `Ready to study, ${student.name}.`}
              </h3>
              <p className="text-sm text-stone-500 dark:text-slate-400 mt-2">
                {isTe
                  ? 'కరెంట్ అఫైర్స్, రాజ్యాంగం, ఆర్థిక శాస్త్రం లేదా ఏదైనా క్లిష్టమైన అంశంపై తెలుగు లేదా ఇంగ్లీష్‌లో వివరణ పొందండి.'
                  : 'Ask for concise Mains/Prelims notes, Telugu translations of complex concepts, or verified explanations of recent events.'}
              </p>
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[88%] rounded-xl p-4 text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === 'user'
                      ? 'bg-[#1E3A8A] dark:bg-[#2563EB] text-white'
                      : 'bg-[#FBF9F5] dark:bg-[#0B1120] border border-stone-200 dark:border-slate-800 text-stone-800 dark:text-slate-200'
                  }`}
                >
                  <div>{msg.text}</div>
                  {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-stone-200 dark:border-slate-800 flex flex-wrap gap-3">
                      {msg.sources.map((src, i) => {
                        const safeUrl = safeExternalHref(src.url);
                        if (!safeUrl) return null;
                        return (
                          <a
                            key={i}
                            href={safeUrl}
                            target="_blank"
                            rel="noopener noreferrer nofollow"
                            className="inline-flex items-center gap-1 text-xs font-medium text-[#1E3A8A] dark:text-[#38BDF8] hover:underline"
                          >
                            <span>{src.title}</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          {loading && (
            <div className="text-xs text-stone-500 dark:text-slate-400">
              {isTe ? 'సమాధానం సిద్ధం చేస్తున్నాము...' : 'Preparing bilingual study notes...'}
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {error && (
          <div
            role="alert"
            className="mx-6 mb-3 p-3 rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 text-xs text-red-700 dark:text-red-300"
          >
            {error}
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void sendQuestion(input);
          }}
          className="p-4 border-t border-stone-200 dark:border-slate-800 flex items-center gap-3"
        >
          <input
            type="text"
            maxLength={1200}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              isTe
                ? 'ఏదైనా కరెంట్ అఫైర్స్ లేదా పరీక్ష సందేహాన్ని అడగండి...'
                : 'Ask about any current affair, constitutional article, or exam topic...'
            }
            className="flex-1 px-4 py-2.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-[#FBF9F5] dark:bg-[#0B1120] text-sm text-stone-900 dark:text-white placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#1E3A8A] dark:focus:ring-[#38BDF8]"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-sm font-medium transition-colors disabled:opacity-50 shrink-0 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>{isTe ? 'పంపండి' : 'Ask'}</span>
          </button>
        </form>
      </section>
    </div>
  );
};
