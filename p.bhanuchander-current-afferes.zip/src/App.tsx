import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  History,
  Languages,
  LogOut,
  Moon,
  Search,
  ShieldAlert,
  Sun,
  Timer,
  X,
} from 'lucide-react';
import { AuthPortal } from './components/AuthPortal';
import { AiTutorView, GlossaryView } from './components/GlossaryAndTutor';
import { InfographicsHub } from './components/InfographicsHub';
import { MockTestCenter } from './components/MockTestCenter';
import { NewsSection } from './components/NewsSection';
import { INITIAL_ARTICLES, INITIAL_MOCK_TESTS } from './data/bilingualContent';
import {
  apiFetch,
  registerUnauthorizedHandler,
  setDeviceTokenForEmail,
  setStoredSessionToken,
} from './lib/api';
import { sanitizeInputText } from './lib/security';
import type {
  GlossaryTerm,
  Language,
  MockTestDeck,
  NewsArticle,
  NewsCategory,
  StudentProfile,
} from './types';

type ActiveTab = 'news' | 'tests' | 'infographics' | 'glossary' | 'tutor';
type RefreshIntervalSec = 0 | 30 | 60 | 300;

export default function App() {
  const [booting, setBooting] = useState(true);
  const [student, setStudent] = useState<StudentProfile | null>(null);

  const [lang, setLang] = useState<Language>(() => {
    try {
      return localStorage.getItem('pb_ca_lang') === 'te' ? 'te' : 'en';
    } catch {
      return 'en';
    }
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('pb_ca_theme') === 'dark';
    } catch {
      return false;
    }
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('news');
  const [activeCategory, setActiveCategory] = useState<NewsCategory | 'saved'>('all');
  const [searchDraft, setSearchDraft] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshRateSec, setRefreshRateSec] = useState<RefreshIntervalSec>(0);

  const [articles, setArticles] = useState<NewsArticle[]>(INITIAL_ARTICLES);
  const [decks, setDecks] = useState<MockTestDeck[]>(INITIAL_MOCK_TESTS);
  const [refreshing, setRefreshing] = useState(false);
  const [refreshError, setRefreshError] = useState('');
  const [lastSyncedAt, setLastSyncedAt] = useState(() => new Date().toISOString());
  const [tutorPrefill, setTutorPrefill] = useState('');
  const [historyOpen, setHistoryOpen] = useState(false);
  const searchAreaRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!historyOpen) return;
    const handleOutsideClick = (e: MouseEvent) => {
      if (searchAreaRef.current && !searchAreaRef.current.contains(e.target as Node)) {
        setHistoryOpen(false);
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setHistoryOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    window.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      window.removeEventListener('keydown', handleEsc);
    };
  }, [historyOpen]);

  // Sync dark mode class on <html>
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    try {
      localStorage.setItem('pb_ca_theme', darkMode ? 'dark' : 'light');
    } catch {
      // Ignore
    }
  }, [darkMode]);

  useEffect(() => {
    try {
      localStorage.setItem('pb_ca_lang', lang);
    } catch {
      // Ignore
    }
  }, [lang]);

  // Verify existing session on startup
  useEffect(() => {
    registerUnauthorizedHandler(() => setStudent(null));
    let active = true;
    (async () => {
      try {
        const res = await apiFetch<{ authenticated: boolean; student: StudentProfile | null }>(
          '/api/auth/session'
        );
        if (active && res.authenticated && res.student) {
          setStudent(res.student);
        }
      } catch {
        // Stay on AuthPortal
      } finally {
        if (active) setBooting(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const syncedCategoriesRef = useRef<Set<string>>(new Set());

  // Automatically fetch free live updates when authenticated or switching to an unsynced category
  useEffect(() => {
    if (!student) {
      syncedCategoriesRef.current.clear();
      return;
    }
    const catKey = activeCategory === 'saved' ? 'all' : activeCategory;
    if (syncedCategoriesRef.current.has(catKey)) return;
    syncedCategoriesRef.current.add(catKey);

    let active = true;
    (async () => {
      try {
        const res = await apiFetch<{ articles: NewsArticle[]; syncedAt: string }>(
          `/api/news/live?category=${encodeURIComponent(catKey)}`
        );
        if (active && Array.isArray(res.articles) && res.articles.length > 0) {
          setArticles((prev) => {
            const existingTitles = new Set(prev.map((a) => a.title.en));
            const fresh = res.articles.filter((a) => !existingTitles.has(a.title.en));
            return [...fresh, ...prev];
          });
          setLastSyncedAt(res.syncedAt || new Date().toISOString());
        }
      } catch {
        // Keep curated bilingual briefings if offline
      }
    })();
    return () => {
      active = false;
    };
  }, [student?.email, activeCategory]);

  const handleRefreshLive = useCallback(async () => {
    if (!student || refreshing) return;
    setRefreshing(true);
    setRefreshError('');
    try {
      const catParam = activeCategory === 'saved' ? 'all' : activeCategory;
      const res = await apiFetch<{ articles: NewsArticle[]; syncedAt: string }>(
        '/api/news/refresh',
        {
          method: 'POST',
          body: JSON.stringify({ category: catParam }),
        }
      );
      if (Array.isArray(res.articles) && res.articles.length > 0) {
        setArticles((prev) => {
          const existingIds = new Set(prev.map((a) => a.title.en));
          const fresh = res.articles.filter((a) => !existingIds.has(a.title.en));
          return [...fresh, ...prev];
        });
        setLastSyncedAt(res.syncedAt || new Date().toISOString());
      }
    } catch (err) {
      setRefreshError(
        err instanceof Error ? err.message : 'Unable to sync live updates right now.'
      );
    } finally {
      setRefreshing(false);
    }
  }, [student, refreshing, activeCategory]);

  // Auto-refresh interval timer
  useEffect(() => {
    if (!student || refreshRateSec === 0) return;
    const id = window.setInterval(() => {
      void handleRefreshLive();
    }, refreshRateSec * 1000);
    return () => window.clearInterval(id);
  }, [student, refreshRateSec, handleRefreshLive]);

  const handleToggleBookmark = async (articleId: string) => {
    if (!student) return;
    const prevBookmarkedIds = student.bookmarkedIds;
    const optimistic = prevBookmarkedIds.includes(articleId)
      ? prevBookmarkedIds.filter((id) => id !== articleId)
      : [articleId, ...prevBookmarkedIds];
    setStudent((prev) => (prev ? { ...prev, bookmarkedIds: optimistic } : prev));

    try {
      const res = await apiFetch<{ bookmarkedIds: string[] }>('/api/progress/bookmark', {
        method: 'POST',
        body: JSON.stringify({ articleId }),
      });
      setStudent((prev) => (prev ? { ...prev, bookmarkedIds: res.bookmarkedIds } : prev));
    } catch {
      // Revert cleanly if request fails
      setStudent((prev) => (prev ? { ...prev, bookmarkedIds: prevBookmarkedIds } : prev));
    }
  };

  const handleLogout = async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // Ignore network error on logout
    }
    syncedCategoriesRef.current.clear();
    setStoredSessionToken('');
    setStudent(null);
  };

  const handleRevokeTrustedDevice = async () => {
    if (!student) return;
    try {
      await apiFetch('/api/auth/revoke-devices', { method: 'POST' });
    } catch {
      // Ignore
    }
    syncedCategoriesRef.current.clear();
    setDeviceTokenForEmail(student.email, '');
    setStoredSessionToken('');
    setStudent(null);
  };

  const updateSearchHistory = async (action: 'add' | 'remove' | 'clear', query?: string) => {
    if (!student) return;
    const current = student.searchHistory || [];
    const cleaned = query ? sanitizeInputText(query, 120) : '';
    let optimistic = current;
    if (action === 'clear') {
      optimistic = [];
    } else if (action === 'remove' && cleaned) {
      optimistic = current.filter((item) => item.toLowerCase() !== cleaned.toLowerCase());
    } else if (action === 'add' && cleaned.length >= 2) {
      optimistic = [
        cleaned,
        ...current.filter((item) => item.toLowerCase() !== cleaned.toLowerCase()),
      ].slice(0, 12);
    } else {
      return;
    }

    setStudent((prev) => (prev ? { ...prev, searchHistory: optimistic } : prev));
    try {
      const res = await apiFetch<{ searchHistory: string[] }>('/api/progress/search-history', {
        method: 'POST',
        body: JSON.stringify({ action, query: cleaned }),
      });
      setStudent((prev) => (prev ? { ...prev, searchHistory: res.searchHistory } : prev));
    } catch {
      // Keep optimistic update on transient hiccup
    }
  };

  const applySearch = (rawTerm: string, saveToHistory = true) => {
    const cleaned = sanitizeInputText(rawTerm, 120);
    setSearchDraft(cleaned);
    setSearchQuery(cleaned);
    setHistoryOpen(false);
    if (cleaned && activeTab !== 'news' && activeTab !== 'glossary') {
      setActiveTab('news');
    }
    if (saveToHistory && cleaned.length >= 2) {
      void updateSearchHistory('add', cleaned);
    }
  };

  const handleAskTutorAboutArticle = (article: NewsArticle) => {
    const prompt =
      lang === 'te'
        ? `"${article.title.te}" వార్త ఆధారంగా UPSC / Group-1 పరీక్షలకు అవసరమైన 4 ముఖ్యమైన పాయింట్లు మరియు ఒక మాక్ ప్రశ్న ఇవ్వండి.`
        : `Provide 4 crisp competitive-exam study notes and 1 practice question based on: "${article.title.en}"`;
    setTutorPrefill(prompt);
    setActiveTab('tutor');
  };

  const handleExplainTermWithAI = (term: GlossaryTerm) => {
    const prompt =
      lang === 'te'
        ? `"${term.term.te} (${term.term.en})" గురించి ప్రస్తుత భారత ఆర్థిక/పాలనా ఉదాహరణలతో వివరించండి.`
        : `Explain "${term.term.en}" with current Indian policy examples and exam pitfalls.`;
    setTutorPrefill(prompt);
    setActiveTab('tutor');
  };

  const isTe = lang === 'te';

  if (booting) {
    return (
      <div className="min-h-screen bg-[#FBF9F5] dark:bg-[#0B1120] flex items-center justify-center px-4">
        <div className="text-center space-y-2">
          <div className="font-display text-2xl font-semibold text-stone-900 dark:text-white">
            p.Bhanuchander current afferes
          </div>
          <div className="text-xs text-stone-500 dark:text-slate-400">
            Restoring verified student session...
          </div>
        </div>
      </div>
    );
  }

  if (!student) {
    return (
      <AuthPortal
        lang={lang}
        onToggleLang={() => setLang((l) => (l === 'en' ? 'te' : 'en'))}
        darkMode={darkMode}
        onToggleDark={() => setDarkMode((d) => !d)}
        onAuthenticated={(authenticatedStudent) => setStudent(authenticatedStudent)}
      />
    );
  }

  const navItems: Array<{ id: ActiveTab; en: string; te: string }> = [
    { id: 'news', en: 'Briefings', te: 'వార్తలు' },
    { id: 'tests', en: 'Mock Tests', te: 'మాక్ టెస్టులు' },
    { id: 'infographics', en: 'Infographics', te: 'ఇన్ఫోగ్రాఫిక్స్' },
    { id: 'glossary', en: 'Glossary', te: 'పదకోశం' },
    { id: 'tutor', en: 'AI Tutor', te: 'AI ట్యూటర్' },
  ];

  return (
    <div className="min-h-screen bg-[#FBF9F5] dark:bg-[#0B1120] text-[#1C1917] dark:text-[#F8FAFC] flex flex-col">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-40 border-b border-stone-200 dark:border-slate-800 bg-white/95 dark:bg-[#0F172A]/95 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('news')}
            className="font-display text-base sm:text-lg font-semibold tracking-tight text-stone-900 dark:text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            p.Bhanuchander current afferes
          </button>

          {/* Zone 2: 5 Concise Single-Line Navigation Links */}
          <nav className="hidden md:flex items-center gap-6" aria-label="Primary navigation">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`py-1 text-sm font-medium border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'border-[#1E3A8A] dark:border-[#38BDF8] text-[#1E3A8A] dark:text-[#38BDF8]'
                      : 'border-transparent text-stone-600 dark:text-slate-300 hover:text-stone-900 dark:hover:text-white'
                  }`}
                >
                  {isTe ? item.te : item.en}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => void handleLogout()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-stone-200 dark:border-slate-700 bg-stone-50 dark:bg-slate-800 text-xs font-medium text-stone-800 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{isTe ? 'లాగ్ అవుట్' : 'Sign Out'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Nav Strip */}
        <div className="md:hidden border-t border-stone-200 dark:border-slate-800 px-4 py-2 flex items-center gap-4 overflow-x-auto">
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`text-xs font-medium whitespace-nowrap shrink-0 py-1 border-b-2 ${
                  active
                    ? 'border-[#1E3A8A] dark:border-[#38BDF8] text-[#1E3A8A] dark:text-[#38BDF8]'
                    : 'border-transparent text-stone-600 dark:text-slate-400'
                }`}
              >
                {isTe ? item.te : item.en}
              </button>
            );
          })}
        </div>
      </header>

      {/* Workspace Utility Toolbar (Student Identity, Search, Language, Theme, Refresh Rate) */}
      <div className="border-b border-stone-200 dark:border-slate-800 bg-[#F3EFE6]/70 dark:bg-[#111827]/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-3.5">
          {/* Student Context */}
          <div className="text-xs text-stone-600 dark:text-slate-300 flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="font-semibold text-stone-900 dark:text-white">{student.name}</span>
            <span aria-hidden="true">·</span>
            <span>{student.educationLevel}</span>
            <span aria-hidden="true">·</span>
            <span className="text-stone-500 dark:text-slate-400">{student.email}</span>
          </div>

          {/* Search & Interactive Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div ref={searchAreaRef} className="relative flex-1 sm:flex-initial">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  applySearch(searchDraft, true);
                }}
                className="flex items-center gap-1.5"
              >
                <div className="relative flex-1 sm:w-60">
                  <Search className="w-4 h-4 text-stone-400 dark:text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    maxLength={120}
                    value={searchDraft}
                    onChange={(e) => {
                      const next = sanitizeInputText(e.target.value, 120);
                      setSearchDraft(next);
                      setSearchQuery(next);
                    }}
                    placeholder={
                      isTe ? 'వార్తలు, పదాలు వెతకండి...' : 'Search news & glossary...'
                    }
                    aria-label="Search current affairs and glossary"
                    className="w-full pl-9 pr-7 py-1.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-white dark:bg-[#0B1120] text-xs text-stone-900 dark:text-white placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#1E3A8A] dark:focus:ring-[#38BDF8]"
                  />
                  {searchDraft && (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchDraft('');
                        setSearchQuery('');
                      }}
                      aria-label="Clear search"
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 dark:hover:text-slate-200 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <button
                  type="submit"
                  aria-label="Apply search"
                  className="px-3 py-1.5 rounded-lg bg-[#1E3A8A] hover:bg-[#172E6E] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  OK
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryOpen((open) => !open)}
                  aria-expanded={historyOpen}
                  aria-label="Toggle search history"
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    historyOpen
                      ? 'border-[#1E3A8A] dark:border-[#38BDF8] bg-[#1E3A8A]/10 dark:bg-[#38BDF8]/15 text-[#1E3A8A] dark:text-[#38BDF8]'
                      : 'border-stone-300 dark:border-slate-700 bg-white dark:bg-[#0B1120] text-stone-800 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <History className="w-3.5 h-3.5" />
                  <span>{isTe ? 'చరిత్ర' : 'History'}</span>
                  {(student.searchHistory?.length || 0) > 0 && (
                    <span className="font-mono-tabular text-[11px] opacity-80">
                      ({student.searchHistory?.length})
                    </span>
                  )}
                </button>
              </form>

              {historyOpen && (
                <div
                  role="region"
                  aria-label="Search history"
                  className="absolute left-0 right-0 sm:right-auto sm:w-80 top-full mt-2 z-50 bg-white dark:bg-[#111827] border border-stone-200 dark:border-slate-700 rounded-xl shadow-lg overflow-hidden"
                >
                  <div className="px-4 py-2.5 border-b border-stone-200 dark:border-slate-800 flex items-center justify-between gap-2 bg-[#FBF9F5] dark:bg-[#0B1120]">
                    <span className="text-xs font-semibold text-stone-800 dark:text-slate-200">
                      {isTe ? 'ఇటీవలి శోధన చరిత్ర' : 'Recent Search History'}
                    </span>
                    {(student.searchHistory?.length || 0) > 0 && (
                      <button
                        type="button"
                        onClick={() => void updateSearchHistory('clear')}
                        className="text-[11px] font-medium text-red-700 dark:text-red-400 hover:underline cursor-pointer"
                      >
                        {isTe ? 'అన్నీ క్లియర్' : 'Clear all'}
                      </button>
                    )}
                  </div>

                  {!student.searchHistory || student.searchHistory.length === 0 ? (
                    <div className="px-4 py-5 text-xs text-stone-500 dark:text-slate-400 text-center">
                      {isTe
                        ? 'ఇంకా శోధన చరిత్ర లేదు. పదాన్ని టైప్ చేసి OK నొక్కండి.'
                        : 'No recent searches yet. Type a topic and click OK.'}
                    </div>
                  ) : (
                    <ul className="max-h-64 overflow-y-auto divide-y divide-stone-100 dark:divide-slate-800">
                      {student.searchHistory.map((term) => (
                        <li
                          key={term}
                          className="flex items-center justify-between gap-2 px-3 py-2 hover:bg-stone-50 dark:hover:bg-slate-800/70 transition-colors"
                        >
                          <button
                            type="button"
                            onClick={() => applySearch(term, true)}
                            className="flex-1 text-left flex items-center gap-2 text-xs text-stone-800 dark:text-slate-200 truncate cursor-pointer"
                          >
                            <History className="w-3.5 h-3.5 text-stone-400 dark:text-slate-500 shrink-0" />
                            <span className="truncate">{term}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => void updateSearchHistory('remove', term)}
                            aria-label={`Remove ${term} from search history`}
                            className="p-1 rounded text-stone-400 hover:text-stone-700 dark:hover:text-slate-200 cursor-pointer shrink-0"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>

            {/* Refresh Rate Control */}
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-white dark:bg-[#0B1120] text-xs">
              <Timer className="w-3.5 h-3.5 text-stone-500 dark:text-slate-400 shrink-0" />
              <label htmlFor="refresh-rate" className="sr-only">
                Auto refresh rate
              </label>
              <select
                id="refresh-rate"
                value={refreshRateSec}
                onChange={(e) => setRefreshRateSec(Number(e.target.value) as RefreshIntervalSec)}
                className="bg-transparent text-stone-800 dark:text-slate-200 font-medium focus:outline-none cursor-pointer"
              >
                <option value={0}>{isTe ? 'రిఫ్రెష్: మాన్యువల్' : 'Refresh: Manual'}</option>
                <option value={30}>{isTe ? 'ప్రతి 30 సె' : 'Auto: 30s'}</option>
                <option value={60}>{isTe ? 'ప్రతి 1 ని' : 'Auto: 1m'}</option>
                <option value={300}>{isTe ? 'ప్రతి 5 ని' : 'Auto: 5m'}</option>
              </select>
            </div>

            {/* Bilingual Toggle */}
            <button
              type="button"
              onClick={() => setLang((l) => (l === 'en' ? 'te' : 'en'))}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-white dark:bg-[#0B1120] text-xs font-medium text-stone-800 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Languages className="w-3.5 h-3.5 text-[#1E3A8A] dark:text-[#38BDF8]" />
              <span>{isTe ? 'English' : 'తెలుగు'}</span>
            </button>

            {/* Dark Mode Toggle */}
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              aria-label="Toggle dark mode"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-300 dark:border-slate-700 bg-white dark:bg-[#0B1120] text-xs font-medium text-stone-800 dark:text-slate-200 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {darkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              <span>{darkMode ? (isTe ? 'లైట్' : 'Light') : isTe ? 'డార్క్' : 'Dark'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-8">
        {activeTab === 'news' && (
          <NewsSection
            lang={lang}
            articles={articles}
            activeCategory={activeCategory}
            onSelectCategory={setActiveCategory}
            searchQuery={searchQuery}
            bookmarkedIds={student.bookmarkedIds}
            onToggleBookmark={(id) => void handleToggleBookmark(id)}
            onAskTutorAboutArticle={handleAskTutorAboutArticle}
            onRefreshLive={() => void handleRefreshLive()}
            refreshing={refreshing}
            lastSyncedAt={lastSyncedAt}
            refreshError={refreshError}
          />
        )}

        {activeTab === 'tests' && (
          <MockTestCenter
            lang={lang}
            decks={decks}
            onAddDeck={(deck) => setDecks((prev) => [deck, ...prev])}
            attempts={student.quizAttempts}
            onAttemptSaved={(updated) => setStudent(updated)}
          />
        )}

        {activeTab === 'infographics' && (
          <InfographicsHub
            lang={lang}
            attempts={student.quizAttempts}
            savedCount={student.bookmarkedIds.length}
          />
        )}

        {activeTab === 'glossary' && (
          <GlossaryView
            lang={lang}
            searchQuery={searchQuery}
            onExplainTermWithAI={handleExplainTermWithAI}
          />
        )}

        {activeTab === 'tutor' && (
          <AiTutorView
            lang={lang}
            student={student}
            prefilledPrompt={tutorPrefill}
            onClearPrefill={() => setTutorPrefill('')}
          />
        )}
      </main>

      {/* Clean Editorial Footer */}
      <footer className="border-t border-stone-200 dark:border-slate-800 bg-white dark:bg-[#0F172A] mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-stone-500 dark:text-slate-400">
          <div>
            <span className="font-semibold text-stone-800 dark:text-slate-200">
              p.Bhanuchander current afferes
            </span>
            <span className="mx-2" aria-hidden="true">
              ·
            </span>
            <span>
              {isTe
                ? 'ఇంగ్లీష్ & తెలుగు ద్వైభాషా కరెంట్ అఫైర్స్ పోర్టల్'
                : 'Bilingual English & Telugu Academic Current Affairs Portal'}
            </span>
          </div>
          <button
            type="button"
            onClick={() => void handleRevokeTrustedDevice()}
            className="inline-flex items-center gap-1.5 text-xs text-stone-500 dark:text-slate-400 hover:text-stone-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>
              {isTe
                ? 'ఈ పరికరం OTP విశ్వాసాన్ని రీసెట్ చేయండి'
                : 'Reset Trusted Device OTP'}
            </span>
          </button>
        </div>
      </footer>
    </div>
  );
}
