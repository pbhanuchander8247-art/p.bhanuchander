import type {
  ConstitutionalHighlight,
  GlossaryTerm,
  InfographicMetric,
  MockTestDeck,
  NewsArticle,
  TimelineMilestone,
} from '../types';

export const EDUCATION_LEVELS = [
  { value: 'UPSC Civil Services', en: 'UPSC Civil Services Aspirant', te: 'UPSC సివిల్ సర్వీసెస్ అభ్యర్థి' },
  { value: 'APPSC / TSPSC Group 1 & 2', en: 'APPSC / TSPSC Group 1 & 2', te: 'APPSC / TSPSC గ్రూప్ 1 & 2' },
  { value: 'SSC / RRB / Banking', en: 'SSC / RRB / Banking Exams', te: 'SSC / RRB / బ్యాంకింగ్ పరీక్షలు' },
  { value: 'Undergraduate / Degree', en: 'Undergraduate / Degree Student', te: 'డిగ్రీ / అండర్ గ్రాడ్యుయేట్ విద్యార్థి' },
  { value: 'Postgraduate', en: 'Postgraduate Scholar', te: 'పోస్ట్ గ్రాడ్యుయేట్ విద్యార్థి' },
  { value: 'High School / 10+2', en: 'High School / Intermediate (10+2)', te: 'హైస్కూల్ / ఇంటర్మీడియట్ (10+2)' },
] as const;

export const CATEGORY_LABELS = {
  all: { en: 'All Briefings', te: 'అన్ని వార్తలు' },
  regional: { en: 'Regional (TS & AP)', te: 'ప్రాంతీయ (TS & AP)' },
  national: { en: 'National', te: 'జాతీయ' },
  international: { en: 'International', te: 'అంతర్జాతీయ' },
  economy: { en: 'Economy & Polity', te: 'ఆర్థికం & పాలిటీ' },
  science: { en: 'Science & Tech', te: 'సైన్స్ & టెక్' },
  sports: { en: 'Awards & Sports', te: 'అవార్డులు & క్రీడలు' },
} as const;

export const INITIAL_ARTICLES: NewsArticle[] = [
  {
    id: 'art-nat-digital-public-infra',
    category: 'national',
    isBreaking: true,
    isLead: true,
    publishedAt: '2026-11-18T08:30:00Z',
    readMinutes: 4,
    imageUrl: '/src/assets/images/national_parliament_india_1795003973488.jpg',
    title: {
      en: 'India Expands Digital Public Infrastructure & AI Governance Framework Across States',
      te: 'రాష్ట్రాల్లో డిజిటల్ పబ్లిక్ ఇన్‌ఫ్రాస్ట్రక్చర్, AI పాలనా విధానాన్ని విస్తరించిన భారత్',
    },
    summary: {
      en: 'New federal digital governance standards integrate multilingual citizen portals, interoperable welfare registries, and verifiable academic credentials for universities and competitive boards.',
      te: 'నూతన జాతీయ డిజిటల్ పాలనా ప్రమాణాలు బహుభాషా పౌర పోర్టల్స్, సంక్షేమ రిజిస్ట్రీలు మరియు విద్యా ధృవపత్రాల ఏకీకరణను వేగవంతం చేస్తున్నాయి.',
    },
    body: {
      en: 'The Ministry of Electronics and Information Technology unveiled an updated Digital Public Infrastructure (DPI) architecture aimed at connecting state-level scholarship systems, district revenue records, and public recruitment boards through open APIs. Under the revised framework, regional language parity—including full Telugu script support in automated document verification—is mandatory for citizen-facing services. Policy analysts note that this lowers administrative friction for rural candidates applying for national fellowships and civil service examinations while enforcing strict data minimization rules.',
      te: 'ఎలక్ట్రానిక్స్ మరియు ఐటీ మంత్రిత్వ శాఖ రాష్ట్ర స్థాయి స్కాలర్‌షిప్ వ్యవస్థలు, జిల్లా రెవెన్యూ రికార్డులు మరియు పబ్లిక్ రిక్రూట్‌మెంట్ బోర్డులను ఓపెన్ APIల ద్వారా అనుసంధానించే నూతన డిజిటల్ పబ్లిక్ ఇన్‌ఫ్రాస్ట్రక్చర్ (DPI) రూపకల్పనను ప్రకటించింది. సవరించిన విధానంలో భాగంగా పౌర సేవలన్నింటిలో తెలుగు సహా ప్రాంతీయ భాషలకు సమాన ప్రాధాన్యత ఇవ్వడం తప్పనిసరి చేయబడింది. దీనివల్ల గ్రామీణ విద్యార్థులు జాతీయ ఫెలోషిప్‌లు, సివిల్ సర్వీసెస్ పరీక్షలకు దరఖాస్తు చేసుకోవడంలో పారదర్శకత పెరుగుతుందని విశ్లేషకులు భావిస్తున్నారు.',
    },
    examRelevance: {
      en: 'UPSC GS-II (Governance & e-Governance) · TSPSC/APPSC Paper-I Current Affairs & Public Policy',
      te: 'UPSC GS-II (పాలన & ఇ-గవర్నెన్స్) · TSPSC/APPSC పేపర్-I కరెంట్ అఫైర్స్',
    },
    examTags: ['UPSC GS-II', 'APPSC Group-1', 'TSPSC Group-1'],
    sources: [
      { title: 'Press Information Bureau (PIB) Archive', url: 'https://pib.gov.in' },
      { title: 'MeitY Digital India Governance', url: 'https://www.meity.gov.in' },
    ],
  },
  {
    id: 'art-reg-hyderabad-life-sciences',
    category: 'regional',
    isBreaking: true,
    publishedAt: '2026-11-18T07:45:00Z',
    readMinutes: 3,
    imageUrl: '/src/assets/images/regional_telangana_ap_1795003972588.jpg',
    title: {
      en: 'Hyderabad & Visakhapatnam Coastal Tech Corridors Announce Skill Fellowships for Graduates',
      te: 'హైదరాబాద్, విశాఖపట్నం టెక్ కారిడార్లలో గ్రాడ్యుయేట్ల కోసం ప్రత్యేక నైపుణ్య ఫెలోషిప్‌లు',
    },
    summary: {
      en: 'Joint regional innovation hubs across Telangana and Andhra Pradesh launch semiconductor, biopharma, and green hydrogen apprenticeship tracks targeting 25,000 youth.',
      te: 'తెలంగాణ, ఆంధ్రప్రదేశ్ ప్రాంతీయ ఆవిష్కరణ కేంద్రాలు సెమీకండక్టర్, బయోఫార్మా, గ్రీన్ హైడ్రోజన్ రంగాల్లో 25,000 మంది యువతకు శిక్షణ కార్యక్రమాలను ప్రారంభించాయి.',
    },
    body: {
      en: 'State industries departments in Telangana and Andhra Pradesh rolled out complementary workforce readiness programs linked to Genome Valley in Hyderabad and the Visakhapatnam-Kakinada industrial corridor. The fellowships emphasize cleanroom manufacturing, clinical data standards, and renewable grid balancing. Competitive exam aspirants should note the clustering of Special Economic Zones (SEZs) and state capital expenditure trends highlighted in the joint whitepaper.',
      te: 'హైదరాబాద్‌లోని జీనోమ్ వ్యాలీ, విశాఖపట్నం-కాకినాడ పారిశ్రామిక కారిడార్లను అనుసంధానిస్తూ తెలంగాణ మరియు ఆంధ్రప్రదేశ్ పరిశ్రమల శాఖలు నూతన నైపుణ్య శిక్షణా కార్యక్రమాలను ప్రకటించాయి. క్లీన్‌రూమ్ తయారీ, క్లినికల్ డేటా ప్రమాణాలు, పునరుత్పాదక విద్యుత్ గ్రిడ్ నిర్వహణపై ఈ ఫెలోషిప్‌లు దృష్టి సారిస్తాయి.',
    },
    examRelevance: {
      en: 'TSPSC & APPSC Economy · Regional Industrial Corridors & Youth Employment Schemes',
      te: 'TSPSC & APPSC ఆర్థిక శాస్త్రం · ప్రాంతీయ పారిశ్రామిక కారిడార్లు మరియు ఉపాధి పథకాలు',
    },
    examTags: ['TSPSC Group-2', 'APPSC Group-2', 'Regional Economy'],
    sources: [
      { title: 'Telangana Industries Portal', url: 'https://industries.telangana.gov.in' },
      { title: 'AP Economic Development Board', url: 'https://apedb.ap.gov.in' },
    ],
  },
  {
    id: 'art-intl-climate-finance',
    category: 'international',
    isBreaking: true,
    publishedAt: '2026-11-18T06:20:00Z',
    readMinutes: 4,
    imageUrl: '/src/assets/images/global_diplomacy_summit_1795003975111.jpg',
    title: {
      en: 'Global Climate Finance Compact Sets Concessional Lending Targets for Developing Grids',
      te: 'అభివృద్ధి చెందుతున్న దేశాల గ్రీన్ గ్రిడ్‌ల కోసం అంతర్జాతీయ క్లైమేట్ ఫైనాన్స్ ఒప్పందం',
    },
    summary: {
      en: 'Multilateral development banks and G20 sherpas finalize lower-interest transition bonds to accelerate grid-scale battery storage and solar parks in the Global South.',
      te: 'గ్లోబల్ సౌత్ దేశాల్లో బ్యాటరీ నిల్వ, సౌరశక్తి ప్రాజెక్టుల వేగవంతం కోసం తక్కువ వడ్డీ ట్రాన్సిషన్ బాండ్లపై బహుపాక్షిక బ్యాంకులు కీలక అంగీకారానికి వచ్చాయి.',
    },
    body: {
      en: 'Delegates at the multilateral climate finance ministerial endorsed a blended-finance facility aimed at lowering borrowing costs for renewable transmission infrastructure. India advocated for predictable technology transfer and exemption of small-scale clean exporters from unilateral carbon border tariffs. The compact establishes annual transparency reviews tracked by the UNFCCC Secretariat.',
      te: 'బహుపాక్షిక క్లైమేట్ ఫైనాన్స్ సదస్సులో పునరుత్పాదక విద్యుత్ ప్రసార మౌలిక సదుపాయాల కోసం రుణ వ్యయాన్ని తగ్గించే బ్లెండెడ్-ఫైనాన్స్ విధానానికి ప్రతినిధులు ఆమోదం తెలిపారు. సాంకేతిక బదిలీ మరియు చిన్న ఎగుమతిదారులకు కార్బన్ బోర్డర్ పన్నుల నుండి మినహాయింపు కోసం భారత్ బలంగా వాదించింది.',
    },
    examRelevance: {
      en: 'UPSC GS-III (Environment & Climate Diplomacy) · International Relations & CBAM',
      te: 'UPSC GS-III (పర్యావరణం & క్లైమేట్ దౌత్యం) · అంతర్జాతీయ సంబంధాలు',
    },
    examTags: ['UPSC GS-III', 'IR & Environment'],
    sources: [
      { title: 'UNFCCC Climate Finance Portal', url: 'https://unfccc.int' },
    ],
  },
  {
    id: 'art-eco-rbi-liquidity',
    category: 'economy',
    isBreaking: true,
    publishedAt: '2026-11-18T05:50:00Z',
    readMinutes: 3,
    title: {
      en: 'RBI Monetary Policy Review Balances Inflation Vigilance With MSME Credit Flow',
      te: 'ద్రవ్యోల్బణ నియంత్రణతో పాటు MSME రుణ ప్రవాహాన్ని సమన్వయం చేసిన ఆర్‌బీఐ ద్రవ్య విధానం',
    },
    summary: {
      en: 'Central bank retains a calibrated stance on benchmark repo rates while expanding UPI-linked credit lines for small rural enterprises and agricultural cooperatives.',
      te: 'బెంచ్‌మార్క్ రెపో రేట్లపై అప్రమత్త వైఖరిని కొనసాగిస్తూనే, గ్రామీణ చిన్న పరిశ్రమల కోసం UPI-ఆధారిత రుణ సదుపాయాలను ఆర్‌బీఐ విస్తరించింది.',
    },
    body: {
      en: 'The Monetary Policy Committee (MPC) underscored resilient domestic manufacturing PMI alongside seasonal food price monitoring. In a parallel regulatory update, the Reserve Bank raised transaction limits on offline-capable UPI Lite wallets and broadened co-lending norms between public sector banks and regional NBFCs supporting micro-entrepreneurs.',
      te: 'ద్రవ్య విధాన కమిటీ (MPC) దేశీయ తయారీ రంగ వృద్ధిని సమీక్షిస్తూ ఆహార ధరల కదలికలను నిశితంగా పరిశీలిస్తోంది. మరో కీలక నిర్ణయంలో, గ్రామీణ చిన్న వ్యాపారుల కోసం ఆఫ్‌లైన్ UPI లైట్ వాలెట్ పరిమితులను పెంచింది.',
    },
    examRelevance: {
      en: 'Banking / RBI Grade B / UPSC GS-III Indian Economy · Monetary Policy Tools',
      te: 'బ్యాంకింగ్ / ఆర్‌బీఐ / UPSC GS-III భారత ఆర్థిక వ్యవస్థ · ద్రవ్య విధాన సాధనాలు',
    },
    examTags: ['Economy', 'Banking', 'UPSC Prelims'],
    sources: [
      { title: 'Reserve Bank of India Press Releases', url: 'https://www.rbi.org.in' },
    ],
  },
  {
    id: 'art-sci-isro-quantum',
    category: 'science',
    publishedAt: '2026-11-17T16:15:00Z',
    readMinutes: 4,
    title: {
      en: 'ISRO & National Quantum Mission Test Free-Space Quantum Key Distribution Link',
      te: 'ఫ్రీ-స్పేస్ క్వాంటమ్ కీ డిస్ట్రిబ్యూషన్ లింక్‌ను విజయవంతంగా పరీక్షించిన ఇస్రో, నేషనల్ క్వాంటమ్ మిషన్',
    },
    summary: {
      en: 'Atmospheric optical link achieves tamper-evident encryption between ground observatories, advancing India’s indigenous satellite-secured communications roadmap.',
      te: 'భూకేంద్రాల మధ్య అత్యంత సురక్షితమైన ఆప్టికల్ క్వాంటమ్ ఎన్‌క్రిప్షన్‌ను విజయవంతంగా ప్రయోగించడం ద్వారా భారత ఉపగ్రహ కమ్యూనికేషన్ రక్షణ మరింత బలోపేతమైంది.',
    },
    body: {
      en: 'Researchers collaborating under the National Quantum Mission (NQM) demonstrated entangled photon key exchange across a multi-kilometer terrestrial optical channel. Because eavesdropping alters photon quantum states immediately, QKD offers physics-grounded security for banking clearinghouses, defence telemetry, and satellite command links.',
      te: 'నేషనల్ క్వాంటమ్ మిషన్ (NQM) కింద పరిశోధకులు బహుళ కిలోమీటర్ల దూరంలో ఫోటాన్ ఎన్‌టాంగిల్‌మెంట్ ద్వారా సురక్షిత సమాచార మార్పిడిని నిరూపించారు. బ్యాంకింగ్ మరియు రక్షణ రంగాల్లో సైబర్ భద్రతకు ఇది కీలక మలుపు కానుంది.',
    },
    examRelevance: {
      en: 'UPSC Prelims & GS-III Science & Technology · National Quantum Mission',
      te: 'UPSC ప్రిలిమ్స్ & GS-III సైన్స్ అండ్ టెక్నాలజీ · నేషనల్ క్వాంటమ్ మిషన్',
    },
    examTags: ['ISRO', 'Science & Tech', 'UPSC GS-III'],
    sources: [
      { title: 'Department of Science & Technology', url: 'https://dst.gov.in' },
    ],
  },
  {
    id: 'art-pol-finance-commission',
    category: 'economy',
    publishedAt: '2026-11-17T12:10:00Z',
    readMinutes: 3,
    title: {
      en: '16th Finance Commission Consultations Review Vertical Devolution & Disaster Grants',
      te: 'రాష్ట్రాలకు పన్నుల వాటా, విపత్తు నిధులపై 16వ ఆర్థిక సంఘం కీలక సంప్రదింపులు',
    },
    summary: {
      en: 'State governments submit memorandums seeking weightage adjustments for demographic performance, forest ecology conservation, and urban local body grants.',
      te: 'జనాభా నియంత్రణ, అటవీ సంరక్షణ, పట్టణ స్థానిక సంస్థల గ్రాంట్లలో వెయిటేజీ మార్పులపై రాష్ట్ర ప్రభుత్వాలు తమ నివేదికలను సమర్పించాయి.',
    },
    body: {
      en: 'Constituted under Article 280 of the Constitution, the 16th Finance Commission is reviewing the horizontal distribution criteria among states for the 2026–2031 award period. Key debates center on balancing per-capita income distance with incentives for states achieving fertility stabilization and renewable energy investments.',
      te: 'రాజ్యాంగంలోని ఆర్టికల్ 280 ప్రకారం ఏర్పాటైన 16వ ఆర్థిక సంఘం 2026–2031 కాలానికి రాష్ట్రాల మధ్య నిధుల పంపిణీ సూత్రాలను సమీక్షిస్తోంది. జనాభా స్థిరీకరణ సాధించిన రాష్ట్రాలకు ప్రోత్సాహకాలపై ప్రధానంగా చర్చ జరుగుతోంది.',
    },
    examRelevance: {
      en: 'Indian Polity Article 280 · Fiscal Federalism (UPSC, APPSC, TSPSC)',
      te: 'భారత రాజ్యాంగం ఆర్టికల్ 280 · ఆర్థిక సమాఖ్య వాదం',
    },
    examTags: ['Polity', 'Article 280', 'Group-1'],
    sources: [
      { title: 'Finance Commission of India', url: 'https://fincomindia.nic.in' },
    ],
  },
  {
    id: 'art-sports-chess-athletics',
    category: 'sports',
    publishedAt: '2026-11-17T09:00:00Z',
    readMinutes: 2,
    title: {
      en: 'Indian Grandmasters & Athletics Contingents Sweep Continental Championships',
      te: 'కాంటినెంటల్ ఛాంపియన్‌షిప్‌లలో భారత గ్రాండ్‌మాస్టర్లు, అథ్లెట్ల విశేష ప్రతిభ',
    },
    summary: {
      en: 'Young chess prodigies from Telangana and Tamil Nadu secure top podium finishes while national relay squads set new championship timing marks.',
      te: 'తెలంగాణ, తమిళనాడుకు చెందిన యువ చెస్ క్రీడాకారులు అగ్రస్థానం సాధించగా, జాతీయ అథ్లెటిక్స్ జట్లు నూతన రికార్డులు నెలకొల్పాయి.',
    },
    body: {
      en: 'Supported by the Target Olympic Podium Scheme (TOPS) and Khelo India regional centers, emerging junior athletes posted personal bests in javelin, 4x400m relay, and classical FIDE tournament play. Sports analysts attribute the surge to standardized sports science clinics across Hyderabad, Patiala, and Bengaluru.',
      te: 'టార్గెట్ ఒలింపిక్ పోడియం స్కీమ్ (TOPS), ఖేలో ఇండియా కేంద్రాల సహకారంతో యువ క్రీడాకారులు జావెలిన్, రిలే మరియు ఫిడే చెస్ టోర్నమెంట్లలో అద్భుత విజయాలు సాధించారు.',
    },
    examRelevance: {
      en: 'SSC CGL / RRB / Group-2 Sports & National Schemes (TOPS, Khelo India)',
      te: 'SSC CGL / RRB / గ్రూప్-2 క్రీడలు & జాతీయ క్రీడా పథకాలు',
    },
    examTags: ['Sports', 'SSC CGL', 'RRB'],
    sources: [
      { title: 'Sports Authority of India', url: 'https://sportsauthorityofindia.nic.in' },
    ],
  },
];

export const INITIAL_MOCK_TESTS: MockTestDeck[] = [
  {
    id: 'deck-daily-ca',
    title: {
      en: 'Daily Bilingual Current Affairs Drill',
      te: 'రోజువారీ ద్వైభాషా కరెంట్ అఫైర్స్ మాక్ టెస్ట్',
    },
    examTrack: 'UPSC / Group-1 & 2',
    durationMinutes: 10,
    positiveMarks: 2,
    negativeMarks: 0.66,
    questions: [
      {
        id: 'q1',
        category: 'economy',
        examTrack: 'UPSC / Group-1',
        question: {
          en: 'Under which Article of the Indian Constitution is the Finance Commission constituted by the President every five years?',
          te: 'భారత రాజ్యాంగంలోని ఏ ఆర్టికల్ ప్రకారం రాష్ట్రపతి ప్రతి ఐదు సంవత్సరాలకు ఒకసారి ఆర్థిక సంఘాన్ని ఏర్పాటు చేస్తారు?',
        },
        options: [
          { en: 'Article 263', te: 'ఆర్టికల్ 263' },
          { en: 'Article 280', te: 'ఆర్టికల్ 280' },
          { en: 'Article 315', te: 'ఆర్టికల్ 315' },
          { en: 'Article 324', te: 'ఆర్టికల్ 324' },
        ],
        correctIndex: 1,
        explanation: {
          en: 'Article 280 empowers the President of India to constitute a Finance Commission to recommend vertical and horizontal tax devolution between the Union and States.',
          te: 'ఆర్టికల్ 280 ప్రకారం కేంద్రం మరియు రాష్ట్రాల మధ్య పన్నుల పంపిణీపై సిఫార్సులు చేయడానికి ఆర్థిక సంఘం ఏర్పాటు చేయబడుతుంది.',
        },
      },
      {
        id: 'q2',
        category: 'science',
        examTrack: 'UPSC Prelims',
        question: {
          en: 'Why is Quantum Key Distribution (QKD) considered intrinsically resistant to undetected eavesdropping?',
          te: 'క్వాంటమ్ కీ డిస్ట్రిబ్యూషన్ (QKD) రహస్య పర్యవేక్షణ (Eavesdropping) నుండి ఎందుకు అత్యంత సురక్షితమైనదిగా పరిగణించబడుతుంది?',
        },
        options: [
          { en: 'It relies on 4096-bit RSA prime factorization', te: 'ఇది 4096-బిట్ RSA ప్రైమ్ ఫ్యాక్టరైజేషన్‌పై ఆధారపడుతుంది' },
          { en: 'Measuring a quantum photon state disturbs it, alerting legitimate parties', te: 'క్వాంటమ్ ఫోటాన్ స్థితిని గమనించడానికి ప్రయత్నిస్తే దాని స్థితి మారి హెచ్చరిక అందుతుంది' },
          { en: 'It blocks all electromagnetic signals around fiber cables', te: 'ఇది ఫైబర్ కేబుల్స్ చుట్టూ ఉన్న విద్యుదయస్కాంత తరంగాలను పూర్తిగా ఆపుతుంది' },
          { en: 'It operates only in vacuum chambers inside space stations', te: 'ఇది అంతరిక్ష కేంద్రాల్లోని శూన్య ప్రదేశంలో మాత్రమే పనిచేస్తుంది' },
        ],
        correctIndex: 1,
        explanation: {
          en: 'Under quantum mechanics (No-Cloning Theorem), intercepting and measuring quantum states alters the photons, immediately revealing any intrusion attempt.',
          te: 'క్వాంటమ్ భౌతికశాస్త్రం ప్రకారం, ఫోటాన్ స్థితిని మధ్యలో గమనించిన వెంటనే దాని లక్షణాలు మారిపోతాయి, తద్వారా చొరబాటు వెంటనే తెలిసిపోతుంది.',
        },
      },
      {
        id: 'q3',
        category: 'regional',
        examTrack: 'TSPSC / APPSC',
        question: {
          en: 'Which major life-sciences research and biopharma cluster is anchored in Hyderabad, Telangana?',
          te: 'తెలంగాణలోని హైదరాబాద్‌లో ఉన్న ప్రముఖ లైఫ్-సైన్సెస్ మరియు బయోఫార్మా క్లస్టర్ ఏది?',
        },
        options: [
          { en: 'Genome Valley', te: 'జీనోమ్ వ్యాలీ' },
          { en: 'Gift City Bio Park', te: 'గిఫ్ట్ సిటీ బయో పార్క్' },
          { en: 'Dholera Biotech Corridor', te: 'ధోలేరా బయోటెక్ కారిడార్' },
          { en: 'Baddi Marine Hub', te: 'బడ్డీ మెరైన్ హబ్' },
        ],
        correctIndex: 0,
        explanation: {
          en: 'Genome Valley in Hyderabad is India’s first systematically developed life-sciences R&D and clean-manufacturing cluster.',
          te: 'హైదరాబాద్‌లోని జీనోమ్ వ్యాలీ భారతదేశంలో మొట్టమొదటి వ్యవస్థీకృత లైఫ్-సైన్సెస్ పరిశోధన మరియు తయారీ క్లస్టర్.',
        },
      },
      {
        id: 'q4',
        category: 'international',
        examTrack: 'UPSC GS-III',
        question: {
          en: 'What does CBAM stand for in global climate and trade policy discussions?',
          te: 'అంతర్జాతీయ వాతావరణ మరియు వాణిజ్య విధాన చర్చల్లో CBAM అంటే ఏమిటి?',
        },
        options: [
          { en: 'Central Banking Asset Mechanism', te: 'సెంట్రల్ బ్యాంకింగ్ అసెట్ మెకానిజం' },
          { en: 'Carbon Border Adjustment Mechanism', te: 'కార్బన్ బోర్డర్ అడ్జస్ట్‌మెంట్ మెకానిజం' },
          { en: 'Clean Biofuel Allocation Mandate', te: 'క్లీన్ బయోఫ్యూయల్ అలకేషన్ మాండేట్' },
          { en: 'Coastal Biodiversity Adaptation Measure', te: 'కోస్టల్ బయోడైవర్సిటీ అడాప్టేషన్ మెజర్' },
        ],
        correctIndex: 1,
        explanation: {
          en: 'CBAM (Carbon Border Adjustment Mechanism) is the EU tariff framework pricing carbon emissions embedded in imported steel, cement, aluminum, and fertilizers.',
          te: 'CBAM అనేది దిగుమతి చేసుకునే ఉక్కు, సిమెంట్, అల్యూమినియం వంటి వస్తువుల కార్బన్ ఉద్గారాలపై యూరోపియన్ యూనియన్ విధించే సరిహద్దు పన్ను విధానం.',
        },
      },
      {
        id: 'q5',
        category: 'economy',
        examTrack: 'SSC / Banking',
        question: {
          en: 'Which body in India sets the benchmark Policy Repo Rate for inflation targeting?',
          te: 'భారతదేశంలో ద్రవ్యోల్బణ నియంత్రణ కోసం బెంచ్‌మార్క్ రెపో రేటును నిర్ణయించే సంస్థ ఏది?',
        },
        options: [
          { en: 'SEBI Board of Governors', te: 'సెబీ బోర్డ్ ఆఫ్ గవర్నర్స్' },
          { en: 'Monetary Policy Committee (MPC)', te: 'ద్రవ్య విధాన కమిటీ (MPC)' },
          { en: 'NITI Aayog Governing Council', te: 'నీతి ఆయోగ్ పాలక మండలి' },
          { en: 'GST Council', te: 'జీఎస్టీ కౌన్సిల్' },
        ],
        correctIndex: 1,
        explanation: {
          en: 'The six-member Monetary Policy Committee (MPC), chaired by the RBI Governor, determines the policy repo rate to keep CPI inflation within the 4% (+/- 2%) band.',
          te: 'ఆర్‌బీఐ గవర్నర్ అధ్యక్షతన ఉండే ఆరుగురు సభ్యుల ద్రవ్య విధాన కమిటీ (MPC) ద్రవ్యోల్బణాన్ని 4% (+/- 2%) పరిధిలో ఉంచేందుకు రెపో రేటును నిర్ణయిస్తుంది.',
        },
      },
    ],
  },
  {
    id: 'deck-ssc-polity-sprint',
    title: {
      en: 'SSC & State Group-2 Polity + GK Sprint',
      te: 'SSC & రాష్ట్ర గ్రూప్-2 పాలిటీ + సాధారణ జ్ఞాన పరీక్ష',
    },
    examTrack: 'SSC CGL / RRB / Group-2',
    durationMinutes: 8,
    positiveMarks: 2,
    negativeMarks: 0.5,
    questions: [
      {
        id: 'sq1',
        category: 'national',
        examTrack: 'SSC / Group-2',
        question: {
          en: 'Which Constitutional Amendment Act lowered the voting age in India from 21 years to 18 years?',
          te: 'భారతదేశంలో ఓటు హక్కు వయస్సును 21 నుండి 18 సంవత్సరాలకు తగ్గించిన రాజ్యాంగ సవరణ చట్టం ఏది?',
        },
        options: [
          { en: '42nd Constitutional Amendment, 1976', te: '42వ రాజ్యాంగ సవరణ, 1976' },
          { en: '61st Constitutional Amendment, 1988', te: '61వ రాజ్యాంగ సవరణ, 1988' },
          { en: '73rd Constitutional Amendment, 1992', te: '73వ రాజ్యాంగ సవరణ, 1992' },
          { en: '86th Constitutional Amendment, 2002', te: '86వ రాజ్యాంగ సవరణ, 2002' },
        ],
        correctIndex: 1,
        explanation: {
          en: 'The 61st Amendment Act (1988) amended Article 326 to lower the voting age for Lok Sabha and State Assembly elections from 21 to 18.',
          te: '1988 నాటి 61వ రాజ్యాంగ సవరణ ద్వారా ఆర్టికల్ 326 ను సవరించి ఓటు హక్కు వయస్సును 21 నుండి 18కి తగ్గించారు.',
        },
      },
      {
        id: 'sq2',
        category: 'sports',
        examTrack: 'SSC / RRB',
        question: {
          en: 'What is the primary objective of the TOPS initiative run by the Ministry of Youth Affairs & Sports?',
          te: 'కేంద్ర క్రీడా మంత్రిత్వ శాఖ అమలు చేస్తున్న TOPS (Target Olympic Podium Scheme) ప్రధాన లక్ష్యం ఏమిటి?',
        },
        options: [
          { en: 'Funding customized training & coaching for elite Olympic medal prospects', te: 'ఒలింపిక్ పతక ఆశావహ క్రీడాకారులకు ప్రత్యేక శిక్షణ, ఆర్థిక సహాయం అందించడం' },
          { en: 'Building university cricket stadiums only', te: 'విశ్వవిద్యాలయాల్లో క్రికెట్ స్టేడియంలు మాత్రమే నిర్మించడం' },
          { en: 'Regulating private broadcasting rights', te: 'ప్రైవేట్ ప్రసార హక్కులను నియంత్రించడం' },
          { en: 'Issuing sports journalism degrees', te: 'స్పోర్ట్స్ జర్నలిజం డిగ్రీలు ఇవ్వడం' },
        ],
        correctIndex: 0,
        explanation: {
          en: 'Launched in 2014, Target Olympic Podium Scheme (TOPS) provides tailored equipment, foreign exposure, and stipends to potential Olympic and Paralympic medalists.',
          te: '2014లో ప్రారంభమైన TOPS పథకం ఒలింపిక్, పారాలింపిక్ క్రీడాకారులకు అంతర్జాతీయ స్థాయి శిక్షణ, పరికరాలు మరియు ఆర్థిక సహాయాన్ని అందిస్తుంది.',
        },
      },
      {
        id: 'sq3',
        category: 'regional',
        examTrack: 'APPSC / TSPSC',
        question: {
          en: 'Which river basin is shared predominantly across Telangana and Andhra Pradesh and hosts the Nagarjuna Sagar & Srisailam projects?',
          te: 'తెలంగాణ, ఆంధ్రప్రదేశ్ రాష్ట్రాల గుండా ప్రవహిస్తూ నాగార్జున సాగర్, శ్రీశైలం ప్రాజెక్టులకు ఆధారమైన ప్రధాన నది ఏది?',
        },
        options: [
          { en: 'Krishna River', te: 'కృష్ణా నది' },
          { en: 'Narmada River', te: 'నర్మదా నది' },
          { en: 'Mahanadi River', te: 'మహానది' },
          { en: 'Kaveri River', te: 'కావేరి నది' },
        ],
        correctIndex: 0,
        explanation: {
          en: 'The Krishna River originates at Mahabaleshwar in Maharashtra and supports major multipurpose projects including Srisailam and Nagarjuna Sagar across Telangana and AP.',
          te: 'మహారాష్ట్రలోని మహాబలేశ్వర్ వద్ద జన్మించే కృష్ణా నదిపై శ్రీశైలం, నాగార్జున సాగర్ వంటి ప్రధాన బహుళార్థసాధక ప్రాజెక్టులు ఉన్నాయి.',
        },
      },
    ],
  },
];

export const GLOSSARY_TERMS: GlossaryTerm[] = [
  {
    id: 'gl-repo-rate',
    category: 'Economy',
    term: {
      en: 'Policy Repo Rate',
      te: 'పాలసీ రెపో రేటు',
    },
    definition: {
      en: 'The interest rate at which the Reserve Bank of India lends short-term funds to commercial banks against government securities.',
      te: 'వాణిజ్య బ్యాంకులకు ప్రభుత్వ సెక్యూరిటీల హామీపై ఆర్‌బీఐ స్వల్పకాలిక రుణాలు ఇచ్చే వడ్డీ రేటు.',
    },
    examContext: {
      en: 'Raising the repo rate absorbs excess liquidity to curb CPI inflation; cutting it stimulates borrowing and investment.',
      te: 'రెపో రేటు పెంచితే ద్రవ్యోల్బణం నియంత్రణలోకి వస్తుంది; తగ్గిస్తే రుణ వితరణ, పెట్టుబడులు పెరుగుతాయి.',
    },
  },
  {
    id: 'gl-fiscal-deficit',
    category: 'Economy',
    term: {
      en: 'Fiscal Deficit',
      te: 'ద్రవ్య లోటు (Fiscal Deficit)',
    },
    definition: {
      en: 'The shortfall between the government’s total expenditure and its total non-borrowed receipts (revenue + non-debt capital receipts) in a fiscal year.',
      te: 'ఒక ఆర్థిక సంవత్సరంలో ప్రభుత్వ మొత్తం వ్యయం మరియు అప్పులు కాని మొత్తం ఆదాయం మధ్య ఉన్న వ్యత్యాసం.',
    },
    examContext: {
      en: 'Tracked as a percentage of GDP under the FRBM Act targets during every Union Budget.',
      te: 'FRBM చట్టం లక్ష్యాల ప్రకారం కేంద్ర బడ్జెట్‌లో GDP శాతంగా దీనిని లెక్కిస్తారు.',
    },
  },
  {
    id: 'gl-dpi',
    category: 'Polity',
    term: {
      en: 'Digital Public Infrastructure (DPI)',
      te: 'డిజిటల్ పబ్లిక్ ఇన్‌ఫ్రాస్ట్రక్చర్ (DPI)',
    },
    definition: {
      en: 'Interoperable, open-standards digital building blocks such as digital identity (Aadhaar), instant payments (UPI), and consent-based data sharing (Account Aggregator).',
      te: 'ఆధార్, UPI చెల్లింపులు, డిజిలాకర్ వంటి ఓపెన్ స్టాండర్డ్స్ ఆధారిత డిజిటల్ ప్రజా సేవా వేదికలు.',
    },
    examContext: {
      en: 'Frequently tested in UPSC GS-II/III as India’s global model for financial inclusion and transparent welfare delivery.',
      te: 'ఆర్థిక సమ్మిళితత్వం, పారదర్శక సంక్షేమ పంపిణీలో భారత నమూనాగా UPSC పరీక్షల్లో తరచుగా అడుగుతారు.',
    },
  },
  {
    id: 'gl-cbam',
    category: 'Environment',
    term: {
      en: 'Carbon Border Adjustment Mechanism (CBAM)',
      te: 'కార్బన్ బోర్డర్ అడ్జస్ట్‌మెంట్ మెకానిజం (CBAM)',
    },
    definition: {
      en: 'A climate trade policy placing a carbon price on imports of emission-intensive goods so domestic decarbonization efforts are not undercut by carbon leakage.',
      te: 'విదేశాల నుండి దిగుమతి అయ్యే అధిక కర్బన ఉద్గార వస్తువులపై విధించే కార్బన్ సరిహద్దు పన్ను విధానం.',
    },
    examContext: {
      en: 'Major point of negotiation between India and the European Union affecting steel, aluminum, and MSME exporters.',
      te: 'భారత్-ఈయూ వాణిజ్య చర్చల్లో ఉక్కు, అల్యూమినియం ఎగుమతులపై ప్రభావం చూపే కీలక అంశం.',
    },
  },
  {
    id: 'gl-article-280',
    category: 'Polity',
    term: {
      en: 'Fiscal Federalism & Article 280',
      te: 'ఆర్థిక సమాఖ్య వాదం & ఆర్టికల్ 280',
    },
    definition: {
      en: 'The constitutional division of taxation powers and revenue sharing between the Union and States, adjudicated quinquennially by the Finance Commission.',
      te: 'కేంద్ర, రాష్ట్ర ప్రభుత్వాల మధ్య పన్నుల ఆదాయ పంపిణీని నిర్దేశించే రాజ్యాంగబద్ధమైన ఆర్థిక వ్యవస్థ.',
    },
    examContext: {
      en: 'Central to 16th Finance Commission debates on vertical devolution (41% share) and horizontal equity weights.',
      te: '16వ ఆర్థిక సంఘం రాష్ట్రాల వాటా (41%) మరియు నిధుల పంపిణీ సూత్రాల చర్చల్లో ప్రధాన అంశం.',
    },
  },
  {
    id: 'gl-qkd',
    category: 'Science',
    term: {
      en: 'Quantum Key Distribution (QKD)',
      te: 'క్వాంటమ్ కీ డిస్ట్రిబ్యూషన్ (QKD)',
    },
    definition: {
      en: 'A cryptographic protocol using quantum states of photons to distribute secret encryption keys with physics-verified tamper detection.',
      te: 'ఫోటాన్ల క్వాంటమ్ స్థితిని ఉపయోగించి సురక్షిత ఎన్‌క్రిప్షన్ కీలను పంపిణీ చేసే అధునాతన సాంకేతికత.',
    },
    examContext: {
      en: 'Flagship milestone under India’s National Quantum Mission and ISRO satellite security trials.',
      te: 'భారత నేషనల్ క్వాంటమ్ మిషన్ మరియు ఇస్రో ఉపగ్రహ భద్రతా ప్రయోగాల్లో ముఖ్యమైన మైలురాయి.',
    },
  },
  {
    id: 'gl-delimitation',
    category: 'Polity',
    term: {
      en: 'Delimitation Commission',
      te: 'నియోజకవర్గాల పునర్విభజన సంఘం',
    },
    definition: {
      en: 'An independent statutory commission established under Article 82 to redraw parliamentary and assembly constituency boundaries based on recent Census data.',
      te: 'జనాభా గణన ఆధారంగా పార్లమెంటు, అసెంబ్లీ నియోజకవర్గాల సరిహద్దులను నిర్ణయించే స్వతంత్ర సంఘం.',
    },
    examContext: {
      en: 'Orders of the Delimitation Commission carry the force of law and cannot be challenged in any court.',
      te: 'పునర్విభజన సంఘం ఆదేశాలకు చట్టబద్ధత ఉంటుంది మరియు వాటిని ఏ న్యాయస్థానంలోనూ సవాలు చేయలేము.',
    },
  },
  {
    id: 'gl-global-south',
    category: 'International',
    term: {
      en: 'Global South Diplomacy',
      te: 'గ్లోబల్ సౌత్ దౌత్యం',
    },
    definition: {
      en: 'Coalition of developing and emerging economies across Asia, Africa, and Latin America advocating equitable debt relief, climate finance, and UN reforms.',
      te: 'ఆసియా, ఆఫ్రికా, లాటిన్ అమెరికాలోని అభివృద్ధి చెందుతున్న దేశాల సమూహం; సమాన వాణిజ్య, వాతావరణ న్యాయం కోసం కృషి చేస్తుంది.',
    },
    examContext: {
      en: 'India’s Voice of Global South Summits and African Union inclusion in the G20 highlight this strategic focus.',
      te: 'G20లో ఆఫ్రికన్ యూనియన్ చేరిక మరియు భారత్ నిర్వహించిన వాయిస్ ఆఫ్ గ్లోబల్ సౌత్ సదస్సులు పరీక్షల్లో ముఖ్యం.',
    },
  },
];

export const MACRO_METRICS: InfographicMetric[] = [
  {
    label: { en: 'Renewable Capacity Share', te: 'పునరుత్పాదక విద్యుత్ వాటా' },
    value: 46.5,
    previousValue: 41.2,
    unit: '%',
    detail: { en: 'Non-fossil fuel share in India’s installed power capacity', te: 'దేశ మొత్తం స్థాపిత విద్యుత్ సామర్థ్యంలో శిలాజేతర ఇంధన వాటా' },
  },
  {
    label: { en: 'UPI Monthly Volume', te: 'UPI నెలవారీ లావాదేవీలు' },
    value: 16.5,
    previousValue: 12.1,
    unit: 'Bn',
    detail: { en: 'Billion real-time retail digital payments settled monthly', te: 'నెలకు జరిగే బిలియన్ల సంఖ్యలో తక్షణ డిజిటల్ చెల్లింపులు' },
  },
  {
    label: { en: 'Capex Allocation Share', te: 'మూలధన వ్యయ వాటా' },
    value: 3.4,
    previousValue: 2.9,
    unit: '% GDP',
    detail: { en: 'Union public capital expenditure for rail, highways & ports', te: 'రైల్వేలు, రహదారులు, ఓడరేవుల కోసం కేంద్ర మూలధన వ్యయం' },
  },
  {
    label: { en: 'Electronics Exports Growth', te: 'ఎలక్ట్రానిక్స్ ఎగుమతుల వృద్ధి' },
    value: 28.4,
    previousValue: 21.6,
    unit: '% YoY',
    detail: { en: 'Driven by PLI smartphone & semiconductor assembly hubs', te: 'PLI పథకం, సెమీకండక్టర్ అసెంబ్లీ కేంద్రాల ద్వారా వృద్ధి' },
  },
];

export const TECH_TIMELINE: TimelineMilestone[] = [
  {
    year: '2023',
    sector: { en: 'Lunar & Solar Exploration', te: 'చంద్ర, సూర్య అన్వేషణ' },
    title: { en: 'Chandrayaan-3 South Pole Landing & Aditya-L1', te: 'చంద్రయాన్-3 దక్షిణ ధ్రువ ల్యాండింగ్ & ఆదిత్య-L1' },
    description: {
      en: 'India became the first nation to soft-land near the lunar south pole and positioned its solar observatory at Lagrange Point L1.',
      te: 'చంద్రుని దక్షిణ ధ్రువంపై సురక్షితంగా దిగిన తొలి దేశంగా భారత్ చరిత్ర సృష్టించింది.',
    },
  },
  {
    year: '2024',
    sector: { en: 'Semiconductors & AI', te: 'సెమీకండక్టర్లు & AI' },
    title: { en: 'IndiaAI Mission & Commercial Fab Approvals', te: 'ఇండియా AI మిషన్ & సెమీకండక్టర్ ఫ్యాబ్ ఆమోదాలు' },
    description: {
      en: 'Dedicated sovereign GPU compute clusters and domestic silicon fabrication plants received Union Cabinet clearance.',
      te: 'సొంత GPU కంప్యూట్ క్లస్టర్లు మరియు దేశీయ చిప్ తయారీ కేంద్రాలకు కేంద్ర మంత్రివర్గం ఆమోదం తెలిపింది.',
    },
  },
  {
    year: '2025',
    sector: { en: 'Space Docking & BioE3', te: 'స్పేస్ డాకింగ్ & బయో-E3' },
    title: { en: 'SpaDeX Orbital Docking & BioE3 Policy', te: 'స్పేడెక్స్ ఆర్బిటల్ డాకింగ్ & బయో-E3 విధానం' },
    description: {
      en: 'ISRO demonstrated autonomous orbital docking, essential for Bharatiya Antariksh Station and lunar sample return.',
      te: 'భారతీయ అంతరిక్ష కేంద్రం నిర్మాణానికి కీలకమైన స్వయంచాలక ఆర్బిటల్ డాకింగ్‌ను ఇస్రో విజయవంతంగా పూర్తి చేసింది.',
    },
  },
  {
    year: '2026',
    sector: { en: 'Quantum & Clean Grid', te: 'క్వాంటమ్ & గ్రీన్ గ్రిడ్' },
    title: { en: 'QKD Trials & Green Hydrogen Corridors', te: 'QKD ప్రయోగాలు & గ్రీన్ హైడ్రోజన్ కారిడార్లు' },
    description: {
      en: 'National Quantum Mission optical trials and coastal green ammonia export hubs enter operational commissioning.',
      te: 'నేషనల్ క్వాంటమ్ మిషన్ ఆప్టికల్ ప్రయోగాలు, తీరప్రాంత గ్రీన్ అమ్మోనియా ఎగుమతి కేంద్రాలు ప్రారంభమయ్యాయి.',
    },
  },
];

export const CONSTITUTION_HIGHLIGHTS: ConstitutionalHighlight[] = [
  {
    article: 'Article 280',
    title: { en: 'Finance Commission of India', te: 'భారత ఆర్థిక సంఘం' },
    significance: {
      en: 'Governs fiscal transfers between Centre and States every five years.',
      te: 'ప్రతి ఐదేళ్లకు కేంద్ర, రాష్ట్రాల మధ్య ఆర్థిక వనరుల పంపిణీని నిర్దేశిస్తుంది.',
    },
    recentNewsLink: {
      en: '16th Finance Commission award formula consultations (2026–2031).',
      te: '16వ ఆర్థిక సంఘం నిధుల పంపిణీ సూత్రాలపై సంప్రదింపులు.',
    },
  },
  {
    article: 'Article 21',
    title: { en: 'Right to Life, Privacy & Clean Environment', te: 'జీవించే హక్కు, గోప్యత & స్వచ్ఛమైన పర్యావరణం' },
    significance: {
      en: 'Expanded judicial scope covering digital privacy and adverse climate impacts.',
      te: 'డిజిటల్ గోప్యత మరియు వాతావరణ మార్పుల నుండి రక్షణను కవర్ చేసే విస్తృత హక్కు.',
    },
    recentNewsLink: {
      en: 'DPDP Act rules & Supreme Court climate-right jurisprudence.',
      te: 'DPDP డేటా రక్షణ నియమాలు & సుప్రీంకోర్టు పర్యావరణ తీర్పులు.',
    },
  },
  {
    article: 'Article 324',
    title: { en: 'Election Commission Superintendence', te: 'ఎన్నికల సంఘం పర్యవేక్షణ' },
    significance: {
      en: 'Ensures free and fair parliamentary, assembly, and presidential elections.',
      te: 'స్వేచ్ఛాయుత, నిష్పక్షపాత పార్లమెంటు, అసెంబ్లీ ఎన్నికల నిర్వహణ.',
    },
    recentNewsLink: {
      en: 'Electoral roll digitization and remote-voting pilot debates.',
      te: 'ఓటరు జాబితా డిజిటలైజేషన్ & రిమోట్ ఓటింగ్ చర్చలు.',
    },
  },
  {
    article: 'Article 243G / 243W',
    title: { en: 'Panchayati Raj & Urban Local Governance', te: 'పంచాయతీ రాజ్ & పట్టణ స్థానిక సంస్థలు' },
    significance: {
      en: 'Empowers grassroots local bodies with decentralized planning and grants.',
      te: 'స్థానిక సంస్థలకు వికేంద్రీకృత ప్రణాళిక, నిధుల అధికారాలను అందిస్తుంది.',
    },
    recentNewsLink: {
      en: 'Municipal green bonds & State Finance Commission allocations.',
      te: 'మున్సిపల్ గ్రీన్ బాండ్లు & రాష్ట్ర ఆర్థిక సంఘం కేటాయింపులు.',
    },
  },
];
