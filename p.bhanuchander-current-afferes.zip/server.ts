import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express, { type NextFunction, type Request, type Response } from 'express';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = 3000;

const DATA_DIR = path.join(__dirname, '.portal-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');
const SECRET_PATH = path.join(DATA_DIR, 'session.key');

const SESSION_COOKIE_NAME = 'pb_session';
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const OTP_TTL_MS = 5 * 60 * 1000; // 5 minutes
const OTP_COOLDOWN_MS = 15 * 1000; // 15 seconds
const MAX_OTP_ATTEMPTS = 5;

const ALLOWED_EDUCATION_LEVELS = new Set([
  'High School / 10+2',
  'Undergraduate / Degree',
  'Postgraduate',
  'UPSC Civil Services',
  'APPSC / TSPSC Group 1 & 2',
  'SSC / RRB / Banking',
]);

interface QuizAttemptRecord {
  id: string;
  deckId: string;
  deckTitle: string;
  examTrack: string;
  score: number;
  maxScore: number;
  accuracyPercent: number;
  correctCount: number;
  totalQuestions: number;
  completedAt: string;
}

interface StudentRecord {
  name: string;
  email: string;
  educationLevel: string;
  otpVerified: boolean;
  verifiedAt: string;
  trustedDeviceHashes: string[];
  quizAttempts: QuizAttemptRecord[];
  bookmarkedIds: string[];
  searchHistory?: string[];
  updatedAt: string;
}

interface OtpChallengeRecord {
  email: string;
  pendingName: string;
  pendingEducationLevel: string;
  codeHash: string;
  salt: string;
  expiresAt: number;
  attempts: number;
  lastRequestedAt: number;
}

interface PortalStore {
  students: Record<string, StudentRecord>;
  otpChallenges: Record<string, OtpChallengeRecord>;
}

interface AuthenticatedRequest extends Request {
  studentEmail?: string;
}

function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  }
}

function getSigningSecret(): string {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 32) {
    return process.env.SESSION_SECRET;
  }
  ensureDataDir();
  if (fs.existsSync(SECRET_PATH)) {
    return fs.readFileSync(SECRET_PATH, 'utf8').trim();
  }
  const generated = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(SECRET_PATH, generated, { mode: 0o600 });
  return generated;
}

const SIGNING_SECRET = getSigningSecret();

function loadStore(): PortalStore {
  ensureDataDir();
  if (!fs.existsSync(STORE_PATH)) {
    return { students: {}, otpChallenges: {} };
  }
  try {
    const raw = fs.readFileSync(STORE_PATH, 'utf8');
    const parsed = JSON.parse(raw) as Partial<PortalStore>;
    return {
      students: parsed.students && typeof parsed.students === 'object' ? parsed.students : {},
      otpChallenges: parsed.otpChallenges && typeof parsed.otpChallenges === 'object' ? parsed.otpChallenges : {},
    };
  } catch {
    return { students: {}, otpChallenges: {} };
  }
}

function saveStore(store: PortalStore): void {
  ensureDataDir();
  const tmpPath = `${STORE_PATH}.${process.pid}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(store, null, 2), { mode: 0o600 });
  fs.renameSync(tmpPath, STORE_PATH);
}

const store: PortalStore = loadStore();

function normalizeEmail(input: unknown): string {
  if (typeof input !== 'string') return '';
  return input.trim().toLowerCase();
}

function isValidEmail(email: string): boolean {
  if (email.length < 5 || email.length > 160) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

function sanitizeText(input: unknown, maxLen: number): string {
  if (typeof input !== 'string') return '';
  return input.replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, maxLen);
}

function sanitizeHttpUrl(input: unknown): string | undefined {
  if (typeof input !== 'string') return undefined;
  const trimmed = input.trim();
  if (!trimmed || trimmed.length > 2048) return undefined;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.toString();
    }
    return undefined;
  } catch {
    return undefined;
  }
}

function hashValue(value: string, salt: string): string {
  return crypto.createHmac('sha256', SIGNING_SECRET).update(`${salt}:${value}`).digest('hex');
}

function hashDeviceToken(token: string): string {
  return crypto.createHmac('sha256', SIGNING_SECRET).update(`device:${token}`).digest('hex');
}

function signSessionToken(email: string): string {
  const payloadObj = {
    email,
    iat: Date.now(),
    exp: Date.now() + SESSION_TTL_MS,
    jti: crypto.randomBytes(12).toString('hex'),
  };
  const payload = Buffer.from(JSON.stringify(payloadObj), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SIGNING_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifySessionToken(token: string): string | null {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  if (!payload || !sig) return null;

  const expectedSig = crypto.createHmac('sha256', SIGNING_SECRET).update(payload).digest('base64url');
  const sigBuf = Buffer.from(sig, 'utf8');
  const expectedBuf = Buffer.from(expectedSig, 'utf8');
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }

  try {
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as {
      email?: string;
      exp?: number;
    };
    if (!decoded.email || typeof decoded.exp !== 'number' || decoded.exp < Date.now()) {
      return null;
    }
    return decoded.email;
  } catch {
    return null;
  }
}

function maskEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (!local || !domain) return email;
  const prefix = local.slice(0, Math.min(2, local.length));
  return `${prefix}${'*'.repeat(Math.max(2, local.length - prefix.length))}@${domain}`;
}

function extractSessionToken(req: Request): string {
  const authHeader = req.headers.authorization;
  if (typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const cookieToken = (req.cookies as Record<string, unknown> | undefined)?.[SESSION_COOKIE_NAME];
  return typeof cookieToken === 'string' ? cookieToken : '';
}

function setSessionCookie(res: Response, token: string): void {
  const isHttps = process.env.APP_URL?.startsWith('https://') || process.env.NODE_ENV === 'production';
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: Boolean(isHttps),
    sameSite: isHttps ? 'none' : 'lax',
    maxAge: SESSION_TTL_MS,
    path: '/',
  });
}

function publicStudentProfile(student: StudentRecord) {
  return {
    name: student.name,
    email: student.email,
    educationLevel: student.educationLevel,
    otpVerified: student.otpVerified,
    verifiedAt: student.verifiedAt,
    quizAttempts: student.quizAttempts,
    bookmarkedIds: student.bookmarkedIds,
    searchHistory: Array.isArray(student.searchHistory) ? student.searchHistory : [],
  };
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const token = extractSessionToken(req);
  const email = verifySessionToken(token);
  if (!email || !store.students[email]?.otpVerified) {
    res.status(401).json({ error: 'Authentication required. Please sign in to access the portal.' });
    return;
  }
  req.studentEmail = email;
  next();
}

// Simple per-IP rate limiter for OTP and AI endpoints
const rateBuckets = new Map<string, { count: number; resetAt: number }>();
function checkRateLimit(key: string, maxRequests: number, windowMs: number): boolean {
  const now = Date.now();
  const entry = rateBuckets.get(key);
  if (!entry || entry.resetAt < now) {
    rateBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (entry.count >= maxRequests) {
    return false;
  }
  entry.count += 1;
  return true;
}

// Periodically prune expired rate-limit buckets and expired OTP challenges
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of rateBuckets.entries()) {
    if (entry.resetAt < now) {
      rateBuckets.delete(key);
    }
  }
  let changed = false;
  for (const [emailKey, challenge] of Object.entries(store.otpChallenges)) {
    if (challenge.expiresAt < now) {
      delete store.otpChallenges[emailKey];
      changed = true;
    }
  }
  if (changed) {
    saveStore(store);
  }
}, 5 * 60_000).unref();

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY_MISSING');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function extractJsonText(raw: string | undefined): string {
  const trimmed = (raw || '').trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  return (fenced ? fenced[1] : trimmed).trim();
}

async function callWithRetry<T>(fn: () => Promise<T>, maxAttempts = 2): Promise<T> {
  let lastErr: unknown;
  for (let i = 0; i < maxAttempts; i++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      const errObj = err as { status?: number; code?: number };
      const status = typeof errObj?.status === 'number' ? errObj.status : errObj?.code;
      // Only retry transient errors or JSON parse issues; never retry auth/validation errors
      if (status && status >= 400 && status < 500 && status !== 429) {
        throw err;
      }
      if (i < maxAttempts - 1) {
        await new Promise((r) => setTimeout(r, 650 * (i + 1)));
      }
    }
  }
  throw lastErr;
}

function formatGeminiError(err: unknown): { status: number; message: string } {
  const errObj = err as { status?: number; code?: number; message?: string };
  const rawStatus = typeof errObj?.status === 'number' ? errObj.status : errObj?.code;
  const msg = err instanceof Error ? err.message : String(err);
  console.error('[Gemini API error]', rawStatus ?? 'unknown', msg.slice(0, 300));

  if (msg.includes('GEMINI_API_KEY_MISSING')) {
    return {
      status: 503,
      message: 'Gemini API key is not configured. Please verify GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (rawStatus === 429 || msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED')) {
    return {
      status: 429,
      message: 'AI quota temporarily reached. Please wait a moment and try again.',
    };
  }
  if (
    rawStatus === 403 ||
    msg.includes('403') ||
    msg.includes('PERMISSION_DENIED') ||
    msg.includes('API_KEY_INVALID')
  ) {
    return {
      status: 403,
      message: 'Gemini API authentication failed. Please check GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (rawStatus === 404 || msg.includes('404') || msg.includes('NOT_FOUND')) {
    return {
      status: 404,
      message: 'Configured Gemini model was not found or is unavailable for this API key.',
    };
  }
  if (rawStatus === 400 || msg.includes('INVALID_ARGUMENT')) {
    return {
      status: 400,
      message: 'Gemini API rejected the request parameters. Please try rephrasing your prompt.',
    };
  }
  return {
    status: 502,
    message: 'Unable to reach AI service right now. Please try again shortly.',
  };
}

function issueOtpChallenge(email: string, name: string, educationLevel: string) {
  const otp = String(crypto.randomInt(100000, 1000000));
  const salt = crypto.randomBytes(16).toString('hex');
  const codeHash = hashValue(otp, salt);
  store.otpChallenges[email] = {
    email,
    pendingName: name,
    pendingEducationLevel: educationLevel,
    codeHash,
    salt,
    expiresAt: Date.now() + OTP_TTL_MS,
    attempts: 0,
    lastRequestedAt: Date.now(),
  };
  saveStore(store);

  const hasExternalSmtp = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER);
  return {
    maskedEmail: maskEmail(email),
    expiresInSeconds: Math.floor(OTP_TTL_MS / 1000),
    deliveryMode: hasExternalSmtp ? 'email' : 'sandbox',
    sandboxOtpPreview: hasExternalSmtp ? undefined : otp,
  };
}

async function startServer() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '100kb', strict: true }));
  app.use(cookieParser());

  // Security headers compatible with AI Studio iframe hosting
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-DNS-Prefetch-Control', 'off');
    res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=()');
    res.setHeader('Content-Security-Policy', "object-src 'none'; base-uri 'self'; form-action 'self';");
    next();
  });

  // Never cache authenticated or OTP API responses; verify same-origin on state-changing requests
  app.use('/api', (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');

    if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') {
      const origin = req.headers.origin;
      if (origin) {
        try {
          const originHost = new URL(origin).host;
          const requestHost = req.headers.host;
          const appHost = process.env.APP_URL ? new URL(process.env.APP_URL).host : '';
          if (originHost !== requestHost && (!appHost || originHost !== appHost)) {
            res.status(403).json({ error: 'Cross-origin request rejected.' });
            return;
          }
        } catch {
          res.status(403).json({ error: 'Invalid request origin.' });
          return;
        }
      }
    }
    next();
  });

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, portal: 'p.Bhanuchander current afferes' });
  });

  // 1. Check active session
  app.get('/api/auth/session', (req, res) => {
    const token = extractSessionToken(req);
    const email = verifySessionToken(token);
    if (!email) {
      res.json({ authenticated: false, student: null });
      return;
    }
    const student = store.students[email];
    if (!student || !student.otpVerified) {
      res.json({ authenticated: false, student: null });
      return;
    }
    res.json({ authenticated: true, student: publicStudentProfile(student) });
  });

  // 2. Login / First-page Portal Entry (Single initial OTP, zero repeat OTP on trusted subsequent logins)
  app.post('/api/auth/login', (req, res) => {
    const ip = req.ip || 'unknown';
    if (!checkRateLimit(`login:${ip}`, 20, 60_000)) {
      res.status(429).json({ error: 'Too many sign-in attempts. Please wait a minute.' });
      return;
    }

    const name = sanitizeText(req.body?.name, 80);
    const email = normalizeEmail(req.body?.email);
    const educationLevel = sanitizeText(req.body?.educationLevel, 60);
    const deviceToken = sanitizeText(req.body?.deviceToken, 128);

    if (name.length < 2) {
      res.status(400).json({ error: 'Please enter the student full name (at least 2 characters).' });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'Please enter a valid Gmail or email address.' });
      return;
    }
    if (!ALLOWED_EDUCATION_LEVELS.has(educationLevel)) {
      res.status(400).json({ error: 'Please select a valid education level.' });
      return;
    }

    const existing = store.students[email];
    const currentTokenEmail = verifySessionToken(extractSessionToken(req));
    const deviceHash = deviceToken ? hashDeviceToken(deviceToken) : '';
    const isTrustedDevice = Boolean(
      existing?.otpVerified &&
        ((deviceHash && existing.trustedDeviceHashes.includes(deviceHash)) ||
          currentTokenEmail === email)
    );

    if (existing && existing.otpVerified && isTrustedDevice) {
      existing.name = name;
      existing.educationLevel = educationLevel;
      existing.updatedAt = new Date().toISOString();
      saveStore(store);

      const sessionToken = signSessionToken(email);
      setSessionCookie(res, sessionToken);
      res.json({
        status: 'AUTHENTICATED',
        requiresOtp: false,
        student: publicStudentProfile(existing),
        sessionToken,
      });
      return;
    }

    const challenge = issueOtpChallenge(email, name, educationLevel);
    res.json({
      status: 'OTP_REQUIRED',
      requiresOtp: true,
      ...challenge,
    });
  });

  // 3. Resend / Request OTP
  app.post('/api/auth/request-otp', (req, res) => {
    const ip = req.ip || 'unknown';
    if (!checkRateLimit(`otp:${ip}`, 10, 60_000)) {
      res.status(429).json({ error: 'OTP request limit reached. Please wait a minute.' });
      return;
    }

    const email = normalizeEmail(req.body?.email);
    const name = sanitizeText(req.body?.name, 80);
    const educationLevel = sanitizeText(req.body?.educationLevel, 60);

    if (!isValidEmail(email) || name.length < 2 || !ALLOWED_EDUCATION_LEVELS.has(educationLevel)) {
      res.status(400).json({ error: 'Valid student name, email, and education level are required.' });
      return;
    }

    const prev = store.otpChallenges[email];
    if (prev && Date.now() - prev.lastRequestedAt < OTP_COOLDOWN_MS) {
      const waitSec = Math.ceil((OTP_COOLDOWN_MS - (Date.now() - prev.lastRequestedAt)) / 1000);
      res.status(429).json({ error: `Please wait ${waitSec}s before requesting another passcode.` });
      return;
    }

    const challenge = issueOtpChallenge(email, name, educationLevel);
    res.json({ status: 'OTP_SENT', ...challenge });
  });

  // 4. Verify OTP (First-time access -> marks account & trusted device permanently verified)
  app.post('/api/auth/verify-otp', (req, res) => {
    const email = normalizeEmail(req.body?.email);
    const otp = sanitizeText(req.body?.otp, 10);

    if (!isValidEmail(email) || !/^\d{6}$/.test(otp)) {
      res.status(400).json({ error: 'Please enter the 6-digit numeric passcode.' });
      return;
    }

    const challenge = store.otpChallenges[email];
    if (!challenge) {
      res.status(400).json({ error: 'No active passcode request found. Please request a new code.' });
      return;
    }
    if (Date.now() > challenge.expiresAt) {
      delete store.otpChallenges[email];
      saveStore(store);
      res.status(400).json({ error: 'This passcode has expired. Please request a fresh one.' });
      return;
    }
    if (challenge.attempts >= MAX_OTP_ATTEMPTS) {
      delete store.otpChallenges[email];
      saveStore(store);
      res.status(429).json({ error: 'Too many incorrect passcode attempts. Please request a new code.' });
      return;
    }

    const candidateHash = hashValue(otp, challenge.salt);
    const expectedBuf = Buffer.from(challenge.codeHash, 'utf8');
    const candidateBuf = Buffer.from(candidateHash, 'utf8');
    const matches =
      expectedBuf.length === candidateBuf.length && crypto.timingSafeEqual(expectedBuf, candidateBuf);

    if (!matches) {
      challenge.attempts += 1;
      saveStore(store);
      const remaining = MAX_OTP_ATTEMPTS - challenge.attempts;
      res.status(401).json({
        error: `Invalid passcode. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`,
      });
      return;
    }

    // OTP verified! Issue trusted device token + persistent session
    const newDeviceToken = crypto.randomBytes(32).toString('hex');
    const newDeviceHash = hashDeviceToken(newDeviceToken);
    const nowIso = new Date().toISOString();

    const existing = store.students[email];
    const student: StudentRecord = existing
      ? {
          ...existing,
          name: challenge.pendingName,
          educationLevel: challenge.pendingEducationLevel,
          otpVerified: true,
          verifiedAt: existing.verifiedAt || nowIso,
          trustedDeviceHashes: [...existing.trustedDeviceHashes.slice(-4), newDeviceHash],
          updatedAt: nowIso,
        }
      : {
          name: challenge.pendingName,
          email,
          educationLevel: challenge.pendingEducationLevel,
          otpVerified: true,
          verifiedAt: nowIso,
          trustedDeviceHashes: [newDeviceHash],
          quizAttempts: [],
          bookmarkedIds: [],
          searchHistory: [],
          updatedAt: nowIso,
        };

    store.students[email] = student;
    delete store.otpChallenges[email];
    saveStore(store);

    const sessionToken = signSessionToken(email);
    setSessionCookie(res, sessionToken);

    res.json({
      status: 'AUTHENTICATED',
      student: publicStudentProfile(student),
      sessionToken,
      deviceToken: newDeviceToken,
    });
  });

  // 5. Logout (preserves trusted device in DB so re-login does not ask for repeat OTP)
  app.post('/api/auth/logout', (req, res) => {
    const isHttps = process.env.APP_URL?.startsWith('https://') || process.env.NODE_ENV === 'production';
    res.clearCookie(SESSION_COOKIE_NAME, {
      httpOnly: true,
      secure: Boolean(isHttps),
      sameSite: isHttps ? 'none' : 'lax',
      path: '/',
    });
    res.json({ ok: true });
  });

  // 6. Optional security control: revoke trusted devices
  app.post('/api/auth/revoke-devices', requireAuth, (req: AuthenticatedRequest, res) => {
    const student = store.students[req.studentEmail!];
    if (student) {
      student.trustedDeviceHashes = [];
      student.otpVerified = false;
      saveStore(store);
    }
    const isHttps = process.env.APP_URL?.startsWith('https://') || process.env.NODE_ENV === 'production';
    res.clearCookie(SESSION_COOKIE_NAME, {
      httpOnly: true,
      secure: Boolean(isHttps),
      sameSite: isHttps ? 'none' : 'lax',
      path: '/',
    });
    res.json({ ok: true });
  });

  // 7. Save quiz score / toggle bookmark
  app.post('/api/progress/quiz', requireAuth, (req: AuthenticatedRequest, res) => {
    const student = store.students[req.studentEmail!];
    if (!student) {
      res.status(404).json({ error: 'Student profile not found.' });
      return;
    }

    const deckId = sanitizeText(req.body?.deckId, 60);
    const deckTitle = sanitizeText(req.body?.deckTitle, 140);
    const examTrack = sanitizeText(req.body?.examTrack, 80);
    const score = Number(req.body?.score);
    const maxScore = Number(req.body?.maxScore);
    const accuracyPercent = Number(req.body?.accuracyPercent);
    const correctCount = Number(req.body?.correctCount);
    const totalQuestions = Number(req.body?.totalQuestions);

    if (
      !deckId ||
      !Number.isFinite(score) ||
      !Number.isFinite(maxScore) ||
      !Number.isFinite(totalQuestions) ||
      !Number.isFinite(correctCount) ||
      maxScore <= 0 ||
      maxScore > 500 ||
      score < 0 ||
      score > maxScore ||
      totalQuestions < 1 ||
      totalQuestions > 100 ||
      correctCount < 0 ||
      correctCount > totalQuestions
    ) {
      res.status(400).json({ error: 'Invalid quiz score payload.' });
      return;
    }

    const record: QuizAttemptRecord = {
      id: `att-${Date.now()}`,
      deckId,
      deckTitle: deckTitle || 'Current Affairs Mock Test',
      examTrack: examTrack || 'Competitive Exam',
      score: Math.round(score * 100) / 100,
      maxScore: Math.round(maxScore * 100) / 100,
      accuracyPercent: Math.max(0, Math.min(100, Math.round(accuracyPercent))),
      correctCount: Math.round(correctCount),
      totalQuestions: Math.round(totalQuestions),
      completedAt: new Date().toISOString(),
    };

    student.quizAttempts = [record, ...student.quizAttempts].slice(0, 30);
    student.updatedAt = new Date().toISOString();
    saveStore(store);

    res.json({ student: publicStudentProfile(student) });
  });

  app.post('/api/progress/bookmark', requireAuth, (req: AuthenticatedRequest, res) => {
    const student = store.students[req.studentEmail!];
    if (!student) {
      res.status(404).json({ error: 'Student profile not found.' });
      return;
    }
    const articleId = sanitizeText(req.body?.articleId, 80);
    if (!articleId) {
      res.status(400).json({ error: 'Article ID is required.' });
      return;
    }
    if (student.bookmarkedIds.includes(articleId)) {
      student.bookmarkedIds = student.bookmarkedIds.filter((id) => id !== articleId);
    } else {
      student.bookmarkedIds = [articleId, ...student.bookmarkedIds].slice(0, 50);
    }
    student.updatedAt = new Date().toISOString();
    saveStore(store);
    res.json({ bookmarkedIds: student.bookmarkedIds });
  });

  app.post('/api/progress/search-history', requireAuth, (req: AuthenticatedRequest, res) => {
    const student = store.students[req.studentEmail!];
    if (!student) {
      res.status(404).json({ error: 'Student profile not found.' });
      return;
    }

    const action = sanitizeText(req.body?.action || 'add', 20);
    const query = sanitizeText(req.body?.query, 120);
    const current = Array.isArray(student.searchHistory) ? student.searchHistory : [];

    if (action === 'clear') {
      student.searchHistory = [];
    } else if (action === 'remove') {
      if (!query) {
        res.status(400).json({ error: 'Query is required to remove search history entry.' });
        return;
      }
      student.searchHistory = current.filter((item) => item.toLowerCase() !== query.toLowerCase());
    } else if (action === 'add') {
      if (query.length < 2) {
        res.json({ searchHistory: current });
        return;
      }
      const deduped = current.filter((item) => item.toLowerCase() !== query.toLowerCase());
      student.searchHistory = [query, ...deduped].slice(0, 12);
    } else {
      res.status(400).json({ error: 'Unsupported search history action.' });
      return;
    }

    student.updatedAt = new Date().toISOString();
    saveStore(store);
    res.json({ searchHistory: student.searchHistory });
  });

  interface NewsDataRawItem {
    article_id?: string;
    title?: string;
    link?: string;
    description?: string | null;
    content?: string | null;
    pubDate?: string;
    image_url?: string | null;
    source_name?: string;
    source_id?: string;
    category?: string[];
  }

  async function fetchNewsDataHeadlines(category: string): Promise<NewsDataRawItem[]> {
    const apiKey = process.env.NEWSDATA_API_KEY?.trim();
    if (!apiKey || apiKey === 'MY_NEWSDATA_API_KEY') {
      return [];
    }

    const params = new URLSearchParams({ apikey: apiKey, language: 'en' });
    if (category === 'regional') {
      params.set('country', 'in');
      params.set('q', 'Telangana OR Andhra Pradesh OR Hyderabad');
    } else if (category === 'national') {
      params.set('country', 'in');
      params.set('category', 'politics,top,education');
    } else if (category === 'international') {
      params.set('category', 'world');
    } else if (category === 'economy') {
      params.set('country', 'in');
      params.set('category', 'business');
    } else if (category === 'science') {
      params.set('country', 'in');
      params.set('category', 'science,technology,environment');
    } else if (category === 'sports') {
      params.set('country', 'in');
      params.set('category', 'sports');
    } else {
      params.set('country', 'in');
      params.set('category', 'top,politics,business,science');
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);
    try {
      const resp = await fetch(`https://newsdata.io/api/1/latest?${params.toString()}`, {
        signal: controller.signal,
      });
      if (!resp.ok) {
        return [];
      }
      const data = (await resp.json()) as { status?: string; results?: NewsDataRawItem[] };
      if (data.status !== 'success' || !Array.isArray(data.results)) {
        return [];
      }
      return data.results.filter((item) => Boolean(item.title && item.link)).slice(0, 6);
    } catch {
      return [];
    } finally {
      clearTimeout(timeout);
    }
  }

  function mapRawNewsItemFallback(item: NewsDataRawItem, category: string, idx: number) {
    const allowedCats = new Set(['regional', 'national', 'international', 'economy', 'science', 'sports']);
    const inferredCat =
      category !== 'all' && allowedCats.has(category)
        ? category
        : item.category?.includes('business')
          ? 'economy'
          : item.category?.includes('science') || item.category?.includes('technology')
            ? 'science'
            : item.category?.includes('world')
              ? 'international'
              : item.category?.includes('sports')
                ? 'sports'
                : 'national';

    const title = sanitizeText(item.title || 'Current Affairs Update', 200);
    const desc = sanitizeText(item.description || item.content || title, 600);
    const sourceName = sanitizeText(item.source_name || item.source_id || 'NewsData Wire', 80);

    let publishedAt = new Date().toISOString();
    if (item.pubDate) {
      const normalized = item.pubDate.includes('T')
        ? item.pubDate
        : `${item.pubDate.replace(' ', 'T')}Z`;
      const parsedDate = new Date(normalized);
      if (!Number.isNaN(parsedDate.getTime())) {
        publishedAt = parsedDate.toISOString();
      }
    }

    const safeImageUrl = sanitizeHttpUrl(item.image_url);
    const safeLink = sanitizeHttpUrl(item.link);

    return {
      id: `nd-${item.article_id || `${Date.now()}-${idx}`}`,
      category: inferredCat,
      isBreaking: idx < 2,
      isLead: false,
      publishedAt,
      readMinutes: 3,
      imageUrl: safeImageUrl && safeImageUrl.startsWith('https://') ? safeImageUrl : undefined,
      title: { en: title, te: title },
      summary: { en: desc, te: desc },
      body: { en: desc, te: desc },
      examRelevance: {
        en: `${sourceName} · Current Affairs Wire`,
        te: `${sourceName} · తాజా కరెంట్ అఫైర్స్`,
      },
      examTags: ['Live Wire', inferredCat.toUpperCase()],
      sources: safeLink ? [{ title: sourceName, url: safeLink }] : [],
    };
  }

  interface FreeRssEntry {
    title: string;
    link: string;
    description: string;
    pubDate: string;
    source: string;
  }

  function decodeXmlEntities(text: string): string {
    return text
      .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
      .replace(/&#(\d+);/g, (_m, dec) => String.fromCodePoint(Number(dec)))
      .replace(/&#x([0-9a-f]+);/gi, (_m, hex) => String.fromCodePoint(parseInt(hex, 16)))
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&nbsp;/g, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function extractXmlTag(block: string, tag: string): string {
    const match = block.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, 'i'));
    return match ? decodeXmlEntities(match[1]) : '';
  }

  function parseRssFeed(xml: string, fallbackSource: string): FreeRssEntry[] {
    const items: FreeRssEntry[] = [];
    const itemMatches = xml.match(/<item>[\s\S]*?<\/item>/gi) || [];
    for (const block of itemMatches.slice(0, 8)) {
      const rawTitle = extractXmlTag(block, 'title');
      const link = extractXmlTag(block, 'link');
      const description = extractXmlTag(block, 'description');
      const pubDate = extractXmlTag(block, 'pubDate');
      const sourceTag = extractXmlTag(block, 'source');

      let cleanTitle = rawTitle;
      let inferredSource = sourceTag || fallbackSource;
      if (!sourceTag && rawTitle.includes(' - ')) {
        const idx = rawTitle.lastIndexOf(' - ');
        if (idx > 12) {
          cleanTitle = rawTitle.slice(0, idx).trim();
          inferredSource = rawTitle.slice(idx + 3).trim();
        }
      }

      if (cleanTitle && link) {
        items.push({
          title: sanitizeText(cleanTitle, 200),
          link,
          description: sanitizeText(description || cleanTitle, 500),
          pubDate,
          source: sanitizeText(inferredSource, 60),
        });
      }
    }
    return items;
  }

  async function fetchRssUrl(url: string, fallbackSource: string): Promise<FreeRssEntry[]> {
    try {
      const resp = await fetch(url, {
        signal: AbortSignal.timeout(7000),
        headers: { 'User-Agent': 'Mozilla/5.0 (compatible; CurrentAffairsPortal/1.0)' },
      });
      if (!resp.ok) return [];
      const xml = await resp.text();
      return parseRssFeed(xml, fallbackSource);
    } catch {
      return [];
    }
  }

  function getFreeFeedUrls(category: string): { enUrl: string; teUrl: string; source: string; cat: string } {
    if (category === 'regional') {
      return {
        enUrl: 'https://news.google.com/rss/search?q=Telangana+OR+%22Andhra+Pradesh%22+OR+Hyderabad&hl=en-IN&gl=IN&ceid=IN:en',
        teUrl: 'https://news.google.com/rss/search?q=%E0%B0%A4%E0%B1%86%E0%B0%B2%E0%B0%82%E0%B0%97%E0%B0%BE%E0%B0%A3+OR+%E0%B0%86%E0%B0%82%E0%B0%A7%E0%B1%8D%E0%B0%B0%E0%B0%AA%E0%B1%8D%E0%B0%B0%E0%B0%A6%E0%B1%87%E0%B0%B6%E0%B1%8D&hl=te&gl=IN&ceid=IN:te',
        source: 'Regional Wire (TS & AP)',
        cat: 'regional',
      };
    }
    if (category === 'international') {
      return {
        enUrl: 'https://feeds.bbci.co.uk/news/world/rss.xml',
        teUrl: 'https://news.google.com/rss/search?q=%E0%B0%85%E0%B0%82%E0%B0%A4%E0%B0%B0%E0%B1%8D%E0%B0%9C%E0%B0%BE%E0%B0%A4%E0%B1%80%E0%B0%AF+%E0%B0%B5%E0%B0%BE%E0%B0%B0%E0%B1%8D%E0%B0%A4%E0%B0%B2%E0%B1%81&hl=te&gl=IN&ceid=IN:te',
        source: 'BBC & World Wire',
        cat: 'international',
      };
    }
    if (category === 'economy') {
      return {
        enUrl: 'https://news.google.com/rss/search?q=India+economy+OR+RBI+OR+%22Union+Budget%22&hl=en-IN&gl=IN&ceid=IN:en',
        teUrl: 'https://news.google.com/rss/search?q=%E0%B0%AD%E0%B0%BE%E0%B0%B0%E0%B0%A4+%E0%B0%86%E0%B0%B0%E0%B1%8D%E0%B0%A5%E0%B0%BF%E0%B0%95+%E0%B0%B5%E0%B1%8D%E0%B0%AF%E0%B0%B5%E0%B0%B8%E0%B1%8D%E0%B0%A5+OR+RBI&hl=te&gl=IN&ceid=IN:te',
        source: 'India Economy Wire',
        cat: 'economy',
      };
    }
    if (category === 'science') {
      return {
        enUrl: 'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml',
        teUrl: 'https://news.google.com/rss/search?q=ISRO+OR+%E0%B0%87%E0%B0%B8%E0%B1%8D%E0%B0%B0%E0%B1%8B+OR+%E0%B0%B8%E0%B1%88%E0%B0%A8%E0%B1%8D%E0%B0%B8%E0%B1%8D&hl=te&gl=IN&ceid=IN:te',
        source: 'Science & ISRO Wire',
        cat: 'science',
      };
    }
    if (category === 'sports') {
      return {
        enUrl: 'https://news.google.com/rss/search?q=India+sports+OR+chess+OR+athletics+OR+cricket&hl=en-IN&gl=IN&ceid=IN:en',
        teUrl: 'https://news.google.com/rss/search?q=%E0%B0%95%E0%B1%8D%E0%B0%B0%E0%B1%80%E0%B0%A1%E0%B0%B2%E0%B1%81+OR+%E0%B0%AD%E0%B0%BE%E0%B0%B0%E0%B0%A4+%E0%B0%95%E0%B1%8D%E0%B0%B0%E0%B1%80%E0%B0%A1%E0%B0%B2%E0%B1%81&hl=te&gl=IN&ceid=IN:te',
        source: 'India Sports Wire',
        cat: 'sports',
      };
    }
    if (category === 'national') {
      return {
        enUrl: 'https://news.google.com/rss/search?q=India+government+OR+Supreme+Court+OR+Parliament+current+affairs&hl=en-IN&gl=IN&ceid=IN:en',
        teUrl: 'https://news.google.com/rss/search?q=%E0%B0%AD%E0%B0%BE%E0%B0%B0%E0%B0%A4+%E0%B0%AA%E0%B1%8D%E0%B0%B0%E0%B0%AD%E0%B1%81%E0%B0%A4%E0%B1%8D%E0%B0%B5%E0%B0%82+OR+%E0%B0%B8%E0%B1%81%E0%B0%AA%E0%B1%8D%E0%B0%B0%E0%B1%80%E0%B0%82%E0%B0%95%E0%B1%8B%E0%B0%B0%E0%B1%8D%E0%B0%9F%E0%B1%81&hl=te&gl=IN&ceid=IN:te',
        source: 'National Affairs Wire',
        cat: 'national',
      };
    }
    return {
      enUrl: 'https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en',
      teUrl: 'https://news.google.com/rss?hl=te&gl=IN&ceid=IN:te',
      source: 'India Live Current Affairs',
      cat: 'national',
    };
  }

  const freeNewsCache = new Map<string, { expiresAt: number; articles: ReturnType<typeof mapRawNewsItemFallback>[] }>();

  async function fetchFreeLiveArticles(category: string) {
    const cacheKey = category || 'all';
    const cached = freeNewsCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.articles;
    }

    const { enUrl, teUrl, source, cat } = getFreeFeedUrls(cacheKey);
    const [enItems, teItems, ndItems] = await Promise.all([
      fetchRssUrl(enUrl, source),
      fetchRssUrl(teUrl, source),
      fetchNewsDataHeadlines(cacheKey),
    ]);

    const combined: ReturnType<typeof mapRawNewsItemFallback>[] = [];

    // Prefer NewsData.io items first if available
    ndItems.slice(0, 3).forEach((item, idx) => {
      combined.push(mapRawNewsItemFallback(item, cacheKey, idx));
    });

    // Add free unlimited English + native Telugu RSS items
    enItems.slice(0, 4).forEach((item, idx) => {
      const teCounterpart = teItems[idx];
      let publishedAt = new Date().toISOString();
      if (item.pubDate) {
        const parsed = new Date(item.pubDate);
        if (!Number.isNaN(parsed.getTime())) {
          publishedAt = parsed.toISOString();
        }
      }
      combined.push({
        id: `rss-${cacheKey}-${Date.now()}-${idx}`,
        category: cat,
        isBreaking: idx < 2,
        isLead: false,
        publishedAt,
        readMinutes: 3,
        imageUrl: undefined,
        title: {
          en: item.title,
          te: teCounterpart?.title || item.title,
        },
        summary: {
          en: item.description,
          te: teCounterpart?.description || teCounterpart?.title || item.description,
        },
        body: {
          en: item.description,
          te: teCounterpart?.description || teCounterpart?.title || item.description,
        },
        examRelevance: {
          en: `${item.source} · Live Public Current Affairs Feed`,
          te: `${teCounterpart?.source || item.source} · తాజా కరెంట్ అఫైర్స్ వార్త`,
        },
        examTags: ['Live Free Wire', cat.toUpperCase()],
        sources: [
          ...(sanitizeHttpUrl(item.link) ? [{ title: item.source, url: sanitizeHttpUrl(item.link)! }] : []),
          ...(teCounterpart && sanitizeHttpUrl(teCounterpart.link)
            ? [{ title: `${teCounterpart.source} (తెలుగు)`, url: sanitizeHttpUrl(teCounterpart.link)! }]
            : []),
        ],
      });
    });

    const deduped = combined.slice(0, 6);
    if (deduped.length > 0) {
      freeNewsCache.set(cacheKey, {
        expiresAt: Date.now() + 60_000,
        articles: deduped,
      });
    }
    return deduped;
  }

  // 8a. Free Live Current Affairs & News Feed (NewsData.io + Free Public EN/TE RSS)
  app.get('/api/news/live', requireAuth, async (req: AuthenticatedRequest, res) => {
    const category = sanitizeText(req.query?.category || 'all', 30);
    const articles = await fetchFreeLiveArticles(category);
    if (articles.length === 0) {
      res.status(502).json({ error: 'Unable to reach live news feeds right now.' });
      return;
    }
    res.json({ articles, provider: 'free-live-wire', syncedAt: new Date().toISOString() });
  });

  // 8b. Direct NewsData.io live headlines endpoint (server-side API proxy)
  app.get('/api/news/headlines', requireAuth, async (req: AuthenticatedRequest, res) => {
    const category = sanitizeText(req.query?.category || 'all', 30);
    const rawItems = await fetchNewsDataHeadlines(category);
    if (rawItems.length === 0) {
      const freeFallback = await fetchFreeLiveArticles(category);
      if (freeFallback.length > 0) {
        res.json({ articles: freeFallback.slice(0, 4), provider: 'free-rss-wire', syncedAt: new Date().toISOString() });
        return;
      }
      res.status(502).json({ error: 'Unable to retrieve live headlines right now.' });
      return;
    }
    const articles = rawItems.slice(0, 4).map((item, idx) => mapRawNewsItemFallback(item, category, idx));
    res.json({ articles, provider: 'newsdata.io', syncedAt: new Date().toISOString() });
  });

  // 8c. Live Current Affairs Refresh (Free RSS + NewsData.io + Optional Gemini Bilingual Enrichment)
  app.post('/api/news/refresh', requireAuth, async (req: AuthenticatedRequest, res) => {
    if (!checkRateLimit(`ai:${req.studentEmail}`, 30, 60_000)) {
      res.status(429).json({ error: 'Refresh rate limit reached. Please wait a moment.' });
      return;
    }

    const category = sanitizeText(req.body?.category || 'all', 30);
    freeNewsCache.delete(category || 'all');

    const liveArticles = await fetchFreeLiveArticles(category);

    if (liveArticles.length > 0) {
      try {
        const ai = getGeminiClient();
        const sourceItems = liveArticles.slice(0, 4).map((item, idx) => ({
          index: idx,
          title: item.title.en,
          description: item.summary.en,
          source: item.sources[0]?.title || 'News Wire',
        }));

        const response = await ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Convert these live news headlines into bilingual (English and natural Telugu) competitive exam briefings for Indian students preparing for UPSC, TSPSC, APPSC, and SSC.
Input headlines:
${JSON.stringify(sourceItems, null, 2)}`,
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  index: { type: Type.INTEGER },
                  category: { type: Type.STRING },
                  title: {
                    type: Type.OBJECT,
                    properties: { en: { type: Type.STRING }, te: { type: Type.STRING } },
                    required: ['en', 'te'],
                  },
                  summary: {
                    type: Type.OBJECT,
                    properties: { en: { type: Type.STRING }, te: { type: Type.STRING } },
                    required: ['en', 'te'],
                  },
                  body: {
                    type: Type.OBJECT,
                    properties: { en: { type: Type.STRING }, te: { type: Type.STRING } },
                    required: ['en', 'te'],
                  },
                  examRelevance: {
                    type: Type.OBJECT,
                    properties: { en: { type: Type.STRING }, te: { type: Type.STRING } },
                    required: ['en', 'te'],
                  },
                  examTags: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                },
                required: ['index', 'category', 'title', 'summary', 'body', 'examRelevance', 'examTags'],
              },
            },
          },
        });

        const allowedCats = new Set(['regional', 'national', 'international', 'economy', 'science', 'sports']);
        const enriched = JSON.parse(extractJsonText(response.text) || '[]') as Array<{
          index: number;
          category: string;
          title: { en: string; te: string };
          summary: { en: string; te: string };
          body: { en: string; te: string };
          examRelevance: { en: string; te: string };
          examTags: string[];
        }>;

        const articles = liveArticles.slice(0, 4).map((base, idx) => {
          const match = enriched.find((e) => e.index === idx) || enriched[idx];
          if (!match) return base;
          const cat = allowedCats.has(match.category) ? match.category : base.category;
          return {
            ...base,
            category: cat,
            title: match.title,
            summary: match.summary,
            body: match.body,
            examRelevance: match.examRelevance,
            examTags: Array.isArray(match.examTags) && match.examTags.length > 0
              ? match.examTags.slice(0, 3)
              : base.examTags,
          };
        });

        res.json({ articles, provider: 'free-wire+gemini', syncedAt: new Date().toISOString() });
        return;
      } catch {
        // Return live NewsData.io + Free Public RSS articles even without Gemini key/quota
        res.json({ articles: liveArticles.slice(0, 4), provider: 'free-live-wire', syncedAt: new Date().toISOString() });
        return;
      }
    }

    res.status(502).json({ error: 'Unable to fetch live news updates right now. Please try again shortly.' });
  });

  // 9. Generate Bilingual Mock Test via Gemini Structured JSON Schema
  app.post('/api/quiz/generate', requireAuth, async (req: AuthenticatedRequest, res) => {
    if (!checkRateLimit(`ai:${req.studentEmail}`, 15, 60_000)) {
      res.status(429).json({ error: 'Rate limit reached. Please wait before generating another test.' });
      return;
    }

    const examTrack = sanitizeText(req.body?.examTrack || 'UPSC / Group-1 & 2', 80);
    const topic = sanitizeText(req.body?.topic || 'Indian Polity, Economy & Current Affairs', 120);

    try {
      const ai = getGeminiClient();
      const parsed = await callWithRetry(async () => {
        const response = await ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Generate a rigorous 5-question multiple-choice mock test for "${examTrack}" focusing on "${topic}".
Every question, all 4 options, and a crisp 1-2 sentence explanation MUST be written in BOTH fluent English (en) and natural Telugu (te) script.`,
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                title: {
                  type: Type.OBJECT,
                  properties: {
                    en: { type: Type.STRING },
                    te: { type: Type.STRING },
                  },
                  required: ['en', 'te'],
                },
                questions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      category: { type: Type.STRING },
                      question: {
                        type: Type.OBJECT,
                        properties: { en: { type: Type.STRING }, te: { type: Type.STRING } },
                        required: ['en', 'te'],
                      },
                      options: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: { en: { type: Type.STRING }, te: { type: Type.STRING } },
                          required: ['en', 'te'],
                        },
                      },
                      correctIndex: { type: Type.INTEGER },
                      explanation: {
                        type: Type.OBJECT,
                        properties: { en: { type: Type.STRING }, te: { type: Type.STRING } },
                        required: ['en', 'te'],
                      },
                    },
                    required: ['category', 'question', 'options', 'correctIndex', 'explanation'],
                  },
                },
              },
              required: ['title', 'questions'],
            },
          },
        });

        const obj = JSON.parse(extractJsonText(response.text) || '{}') as {
          title?: { en: string; te: string };
          questions?: Array<{
            category: string;
            question: { en: string; te: string };
            options: Array<{ en: string; te: string }>;
            correctIndex: number;
            explanation: { en: string; te: string };
          }>;
        };
        if (!Array.isArray(obj.questions) || obj.questions.length === 0) {
          throw new Error('No questions returned from AI model');
        }
        return obj;
      });

      const allowedCats = new Set(['regional', 'national', 'international', 'economy', 'science', 'sports']);
      const questions = (parsed.questions || [])
        .filter((q) => q?.question?.en && Array.isArray(q.options) && q.options.length >= 2)
        .slice(0, 5)
        .map((q, idx) => {
          const opts = q.options.slice(0, 4);
          return {
            id: `aiq-${Date.now()}-${idx}`,
            category: allowedCats.has(q.category) ? q.category : 'national',
            examTrack,
            question: {
              en: q.question.en,
              te: q.question.te || q.question.en,
            },
            options: opts.map((o) => ({
              en: o?.en || '',
              te: o?.te || o?.en || '',
            })),
            correctIndex: Math.max(0, Math.min(opts.length - 1, Number(q.correctIndex) || 0)),
            explanation: {
              en: q.explanation?.en || 'Refer to official exam syllabus.',
              te: q.explanation?.te || q.explanation?.en || 'అధికారిక సిలబస్ చూడండి.',
            },
          };
        });

      if (questions.length === 0) {
        throw new Error('No valid questions generated');
      }

      res.json({
        deck: {
          id: `deck-ai-${Date.now()}`,
          title: parsed.title || { en: `${examTrack} Practice Set`, te: `${examTrack} ప్రాక్టీస్ టెస్ట్` },
          examTrack,
          durationMinutes: 8,
          positiveMarks: 2,
          negativeMarks: 0.66,
          questions,
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  // 10. Intelligent Bilingual AI Study Assistant
  app.post('/api/assistant/ask', requireAuth, async (req: AuthenticatedRequest, res) => {
    if (!checkRateLimit(`ai:${req.studentEmail}`, 25, 60_000)) {
      res.status(429).json({ error: 'Rate limit reached. Please wait a moment.' });
      return;
    }

    const question = sanitizeText(req.body?.question, 1200);
    const responseLanguage = sanitizeText(req.body?.language || 'bilingual', 20);
    const useWebSearch = Boolean(req.body?.useWebSearch);
    const student = store.students[req.studentEmail!];

    if (question.length < 2) {
      res.status(400).json({ error: 'Please enter a question or topic for the study assistant.' });
      return;
    }

    const langDirective =
      responseLanguage === 'te'
        ? 'Respond clearly in natural, academic Telugu (తెలుగు) suitable for competitive exam preparation.'
        : responseLanguage === 'en'
          ? 'Respond clearly in structured, crisp English suitable for competitive exam preparation.'
          : 'Respond in Bilingual format: first provide a crisp English explanation, followed by an accurate Telugu (తెలుగు) summary section.';

    try {
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: question,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction: `You are the Bilingual Study Tutor for the portal "p.Bhanuchander current afferes".
The student is ${student?.name || 'Student'} studying at the "${student?.educationLevel || 'Competitive Exam'}" level.
${langDirective}
Keep explanations accurate, exam-focused (highlight key facts, constitutional articles, dates, or definitions), and easy to revise.`,
          ...(useWebSearch ? { tools: [{ googleSearch: {} }] } : {}),
        },
      });

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const sources = chunks
        .map((c) => {
          const web = (c as { web?: { uri?: string; title?: string } }).web;
          const safeUrl = sanitizeHttpUrl(web?.uri);
          return safeUrl ? { title: sanitizeText(web?.title || 'Reference Source', 100), url: safeUrl } : null;
        })
        .filter((x): x is { title: string; url: string } => x !== null)
        .slice(0, 4);

      res.json({
        answer: response.text || 'No response generated.',
        sources,
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  // Vite dev middleware or production static build
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  // Global Express error handler preventing internal error/stack leakage
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof SyntaxError && 'body' in err) {
      res.status(400).json({ error: 'Malformed JSON request body.' });
      return;
    }
    res.status(500).json({ error: 'Internal server error.' });
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Portal server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
